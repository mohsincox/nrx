<?php 
	//print_r($customer_info);die();
?>

@extends('masterpage')

@section('content')
<div id="content">
<div class="grid_container">
<div class="grid_12">
				<div class="widget_wrap">
					<div class="widget_top">
						<span class="h_icon blocks_images"></span>
						<h6>ISO Report</h6>
								<h6><strong>From Date :</strong> &nbsp;<?php  $date=date_create($fdate); echo date_format($date,"d-m-Y");?></h6>
						
						<h6><strong>To Date:</strong>&nbsp;<?php  $date=date_create($tdate); echo date_format($date,"d-m-Y");?></h6>
					</div>
					<div class="widget_content">
					
					<div class="btn_30_dark">
						<a href="/IMS/isoreportdownload/<?php echo $fdate; ?>/<?php echo $tdate; ?>"><span class="icon doc_excel_csv_co"></span><span class="btn_link">Download ISO Report</span></a>
					</div>
			
<style>
table, th, td {
    border: 1px solid black;
	
}
 th, td {
    
	width:200px;
}
</style>
			
<div style="overflow-y:scroll; overflow-x:scroll; height:500px;width:100%;">	
<table >
						<thead>

  <tr>
   <th>SL NO</th>
   <th>Customer Name</th>
   <?php
     foreach($item_info as $item){
	   echo '<th>'.$item->iname.'</th>';	 
	 }	 
   ?>
  
  </tr>
  </thead>
  <tbody>
 <?php
	$i=1;
	foreach($customer_info as $c){
	?>
	<tr>
	<td><?php echo $i; ?></td>
	<td><b><?php echo $c->name; ?></b></td>
     <?php 
     $i++;
	 $ctotal=0;
	foreach($item_info as $item){
		
	 ?>
	 <td>
	 <?php
	     //echo $c->id.','.$item->id..$fdate.$tdate;
		 $count=$sales = DB::table('sales')
				->join('salesdetails', 'salesdetails.salesid', '=', 'sales.id')
				->where('sales.customerid','=',$c->id)
				->where('sales.status','=',1)
				->where('salesdetails.itemid','=',$item->id)
				//->groupBy('salesdetails.itemid')
				->whereBetween('salesdetails.created_at', [$fdate, $tdate])
				->sum('salesdetails.quantity');
		echo $count;
		//$ctotal=$ctotal+$count;
	 ?>
	 </td>
	 <?php
	 }
	}
   ?>
  
  </tr>
  <tr>
	<th></th>
	<th>Total</th>
	<?php
    foreach($item_info as $item){
		
	 ?>
	 <th>
	 <?php
	     //echo $c->id.','.$item->id..$fdate.$tdate;
		 $total_count=$sales = DB::table('sales')
				->join('salesdetails', 'salesdetails.salesid', '=', 'sales.id')
				->where('sales.status','=',1)
				->where('salesdetails.itemid','=',$item->id)
				//->groupBy('salesdetails.itemid')
				->whereBetween('salesdetails.created_at', [$fdate, $tdate])
				->sum('salesdetails.quantity');
		echo $total_count;
		//$ctotal=$ctotal+$count;
	 ?>
	 </th>
	 <?php
	 }  	
	
	?>
  </tr>	
	
 </tbody>
</table>					
</div>						
					
					</div>
				</div>
</div></div></div>

@endsection





