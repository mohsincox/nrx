
<table>
 <tbody>
  <tr>
   <td>SL NO</td>
   <td>Branch Name</td>
   <td>Items Name</td>
   <td>Serial No.</td>
   
  </tr>
 <?php
	$i=1;
	foreach($factioyitems as $c){
	?>
	<tr>
   <td><?php echo $i; ?></td>
   <td><?php echo $c->branchname; ?></td>
   <td><?php echo $c->itemsname; ?></td>
   <td><?php echo $c->slno; ?></td>
   
   <?php 
   $i++;
	}
   ?>
   
  </tr>
  
 </tbody>
</table>