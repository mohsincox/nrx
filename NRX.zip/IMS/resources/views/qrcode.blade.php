<?php
	use QrCode;
	$qrcode= QrCode::generate('Make me into a QrCode!');
	echo $qrcode;
	foreach($items as $t){
		 $t->cname.$t->subname.$t->slno.$t->idate;
	}
 ?>