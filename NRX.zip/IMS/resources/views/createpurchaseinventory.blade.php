@extends('masterpage')

@section('content')
<div id="content">
		<div class="grid_container">
			<div class="grid_12 full_block">
				<div class="widget_wrap">
					<div class="widget_top">
						<span class="h_icon list_image"></span>
						<h6>Add Purchase Inventory</h6>
					</div>
					@if (count($errors) > 0)
            <div>
              
              <ul>
                @foreach ($errors->all() as $error)
                  <li style="color:red;"><b>{{ $error }}</b></li>
                @endforeach
              </ul>
            </div>
          @endif
					<div class="widget_content">
						<h3>Create Purchase Inventory</h3>
						<h3 style="color:red;"><?php if(!empty($massege)){ echo $massege; }?></h3>
						<form action="/IMS/purchaseinventory/register" method="post" class="form_container left_label">
						<input type="hidden" name="_token" value="{{ csrf_token() }}">
						<input type="hidden" name="userid" value="{{ Auth::id() }}">
							<ul>
								<li>
								<div class="form_grid_12">
									<label class="field_title"> Item Name:<span class="req">*</span></label>
									<div class="form_input">
										<select class="chzn-select" style=" width:100%" name="itemsid"> 
                                    <?php 
									     $items_info=DB::table('items')
										 ->join('itemssubgroup', 'itemssubgroup.id', '=', 'items.itemssubgroupid')
                                         ->where('itemssubgroup.itemgroupid','=',2)
										 ->select('items.id','items.name')										 
										 ->get(); 
									?> 
                                     <?php foreach($items_info as $t) { ?>
                         <option value="<?php echo $t->id; ?>" <?php echo 'selected'?>><?php echo $t->name; ?></option>
                                    	   <?php }?>
                                 
                                </select>
									</div>
								</div>
								</li>
								<li>
								<div class="form_grid_12">
									<label class="field_title"> Quantity:<span class="req">*</span></label>
									<div class="form_input">
										<input name="quantity" type="text" tabindex="2" step="any" required style="width:100%"/>
									</div>
								</div>
								</li>
								<li>
								<div class="form_grid_12">
									<div class="form_input">
									    <button type="submit" class="btn_small btn_blue"><span>Submit</span></button>
									</div>
								</div>
								</li>
							</ul>
						</form>
					</div>
				</div>
			</div>
		</div>
		<span class="clear"></span>
	</div>
@endsection
