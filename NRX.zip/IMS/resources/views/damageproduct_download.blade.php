
<table>
 <tbody>
  <tr>
   <td>SL NO</td>
   <td>Item Name</td>
   <td>Damage SL NO</td>
   <td>Customer Name</td>
   <td>Invoice No</td>
   <td>Date</td>
   
  </tr>
 <?php
	$i=1;
	foreach($damageproduct as $c){
	?>
	<tr>
   <td><?php echo $i; ?></td>
   <td><?php echo $c->itemsname; ?></td>
   <td><?php echo $c->slno; ?></td>
   <td><?php echo $c->cname; ?></td>
   <td><?php echo $c->salesname; ?></td>
   <?php
		$damagedate=$c->updated_at;
		$ddate=date_create($damagedate);
	?>
   <td><?php echo date_format($ddate,"d-m-Y"); ?></td>
   
   <?php 
   $i++;
	}
   ?>
   
  </tr>
  
 </tbody>
</table>