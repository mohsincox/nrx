@extends('masterpage')

@section('content')

<?php 
$userid=Auth::id();
//echo $userid;
foreach($profile as $com){
$id=$com->id;
}
?>

	<div id="content">
	    		
		<div class="grid_container">
			<div class="grid_12">
				<div class="widget_wrap">
						
					<div class="widget_top">   
						<span class="h_icon list"></span>
						<h6>Invoice for Replace Returns</h6>
					
							<form action="search" method="post">
							    <input type="hidden" name="_token" value="{{ csrf_token() }}">
								<ul id="search_box">
									<li>
									<input name="slno" type="text" class="search_input" id="suggest1" placeholder="Enter Slno no...">
									</li>
									<li>
									<input name="" type="submit" value="" class="search_btn">
									</li>
								</ul>
							</form>
					</div>
					<div class="widget_content">
					
						<div class=" page_content">
					
						
							<div class="invoice_container">
							<div class="header">

<h1><?php if(!empty($com)){echo $com->name;} ?></h1><br><address>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php if(!empty($com)){echo $com->address;} ?><br>
&nbsp;&nbsp;&nbsp;&nbsp;
Tel:<?php if(!empty($com)){echo $com->telephone;} ?> ,Mobile: <?php if(!empty($com)){echo $com->mobile;} ?><br>

E-mail:<?php if(!empty($com)){echo $com->email;} ?><br> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="<?php if(!empty($com)){echo $com->url;} ?> " target="_blank"> <?php if(!empty($com)){echo $com->url;} ?></a><br>

</address>



</div><br>
<div class="clear"></div>
							
								<div class="invoice_action_bar">
									
									<div class="btn_30_light">
									    <?php  if(!empty($factioyitems)){
										$replace_factory = DB::table('replace_factory')
										                  ->join('replacechallan','replace_factory.repalcechallanid','=','replacechallan.id')
														  ->select('replacechallan.id','replacechallan.name')
										                  ->where('factoryitemsid',$factioyitems->id)
														  ->get();				
										foreach($replace_factory as $f){
										?>
										<a href="/IMS/home/replace/pdf/<?php echo $f->id; ?>" title="Print"><?php echo $f->name;?></a>
										<?php } } ?>
									</div>
									
								</div>
							
								<span class="clear"></span>
								<div class="grid_12 invoice_title">
									<h5><u>INVOICE/BILL</u></h5>
								</div>
								<?php  
								  // $sales = DB::table('sales')->where('name',$inno)->first();
								  // if($sales!=NULL){
								//	  $customers = DB::table('customers')->where('id',$sales->customerid)->get();
								 //     print_r($customers); 
								 //  }
								 								 //foreach($value1 as $p){?>
								<div class="grid_6 invoice_to">
									<ul>
										<li>
										<strong><span>Name/Title:<?php if(!empty($customers)){echo $customers->name;} ?></span></strong>
										<span>Address:<?php if(!empty($customers)){echo $customers->preaddress;}?></span>
										<span>Mobile No:<?php if(!empty($customers)){echo $customers->phone;}?></span>
										</li>
									</ul>
								</div>
								<div class="grid_6 invoice_from">
									<ul>
										<li>
										<strong><span>Date:<?php  if(!empty($sales)){echo $sales->created_at;}?></span></strong>
										<span>SI No:<?php  if(!empty($sales)){echo $sales->name;}?></span>
										<span>Voucher No:<?php  if(!empty($sales)){echo $sales->name;}?></span>
										
										</li>
									</ul>
								</div><?php // }?>
								<span class="clear"></span>
								<div class="grid_12 invoice_details">
									<div class="invoice_tbl">
										<table>
										<thead>
										<tr class="gray_sai">
											<th>
												Item Name
											</th>
											<th>
												Serial No
											</th>
											<th>
												Replace Serial No
											</th>
											<th>
												Status
											</th>
										</tr>
										</thead>
										<tbody>
										<tr>
											<td>
												<?php  if(!empty($items)){echo $items->name; $itemsid=$items->id; }?>
											</td>
											<td>
												<?php  if(!empty($factioyitems)){
													if($factioyitems->dstatus==1){
														echo "This Slno. Already Demage";
													}else{
														echo $factioyitems->slno;
													}												
												}?>
											</td>
											<td>
											<?php 
											if(!empty($factioyitems)){
											if($factioyitems->dstatus!=1)
											{
											?>
											
											<form action="replace" method="post">
											    <input type="hidden" name="_token" value="{{ csrf_token() }}">
											<input type="hidden" name="itemsid" value="<?php  if(!empty($factioyitems)){echo $factioyitems->id;}?>">
											  
												<input type="hidden" name="userid" value="<?php echo $userid;?>">
												<input type="hidden" name="randomno" value="<?php echo rand();?>">
											    <input type="hidden" name="inno" value="<?php  if(!empty($sales)){echo $sales->id;}?>" />
											    <div style="height:100px;overflow:scroll;">
												<input type="radio" name="slno" value="<?php echo $factioyitems->id;?>">SAME PRODUCT<br><br>
											    <?php
												   
												    if(!empty($itemsid)){
												    $factioy=DB::table('factioyitems')
													         ->where('salesid',NULL)
															 ->where('itemsid',$itemsid)
															 ->get();
													if(!empty($factioy)){
                                                    foreach($factioy as $f){  														
												?>
												   
												   <input type="radio" name="slno" value="<?php echo $f->id;?>"><?php echo $f->slno; ?><br>
  <br>
												
												<?php } } }?>
												</div>
											</td>
											<td>
												<input name="" type="submit" value="Replace" >
											</td>
											</form>
											<?php } } ?>
										</tr>
										
										</tbody>
										</table>
									</div>
									<p class="amount_word">
										
									</p>
								
								</div>
								<span class="clear"></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<span class="clear"></span>
	</div>

	<div id="content">
<div class="grid_container">
<div class="grid_12">
			<?php   
			//print_r($voucher); die(); 
			    $replace = DB::table('replacechallan')
				->join('replace_factory', 'replace_factory.repalcechallanid', '=', 'replacechallan.id')
				->join('factioyitems', 'factioyitems.id', '=', 'replace_factory.factoryitemsid')
				->join('sales', 'factioyitems.salesid', '=', 'sales.id')
				->join('customers', 'customers.id', '=', 'sales.customerid')
				->select('customers.name as cname','replacechallan.id as rid')
				->groupBy('customers.name')
				->where('replacechallan.created_at',date("Y/m/d"))
				->get();
			    //print_r($replace);die();
			?>		
					
						
						<table class="display data_tbl_search">
						<thead>
						<tr>
						

	<div class="widget_top">
						<span class="h_icon blocks_images"></span>
						<h6>Repalce Return</h6>
					</div>
					<div class="widget_content">
							<th>
								Slno
							</th>
							<th>
								 Customer Name
							</th>
							<th>
								PrintChallan
							</th>
						</tr>
						</thead>
						<tbody>
						<?php $i=1; foreach($replace as $v){?>
						<tr class="gradeC">
							<td class="center">
								 <?php echo $i;?>
							</td>
							
							<td class="center">
								<?php echo $v->cname;?>
							</td>
							<td class="center">
							    <div class="btn_30_orange">
									<a href="/IMS/home/replace/pdf/<?php echo $v->rid;?>"><span class="icon doc_access_co"></span><span class="btn_link">Print</span></a>
								</div>
							</td>
							
						</tr>
						<?php $i++; }?>
						
						</tbody>
						
						</table>
						</div>
						
						

</div></div></div>
	
<script>

function active_to_inactive(factory_item_id) {
	    $_token = "{{ csrf_token() }}";
            $.ajax({
	            type: "POST",
	            url: "search/return_item",
	            data: {
					_token: $_token,
					factory_item_id: factory_item_id,
					},
	            success: function (response) {
	            	if(response == 0){
	            		alert("Not found this item.");
	            	} else if(response == 1){
	            		location.reload();
	            	} else if(response == 2){
	            		alert("Not available this item.");
	            	}
	           	}
	        });
}

function inactive_to_active(factory_item_id){
		$_token = "{{ csrf_token() }}";
			$.ajax({
	            type: "POST",
	            url: "search/return_item_ina_to_act",
	            data: {
					_token: $_token,
					factory_item_id: factory_item_id,
					},
	            success: function (response) {
	            	if(response == 0){
	            		alert("Not found this item.");
	            	} else if(response == 1){
	            		location.reload();
	            	} else if(response == 2){
	            		alert("Not found last inactive.");
	            	}
	           	}
	        });
}

</script>

@endsection

