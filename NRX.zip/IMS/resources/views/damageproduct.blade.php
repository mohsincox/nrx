@extends('masterpage')

@section('content')
<div id="content">
<div class="grid_container">
<div class="grid_12">
				<div class="widget_wrap">
					<div class="widget_top">
						<span class="h_icon blocks_images"></span>
						<h6>Damage Product</h6>
					</div>
					<div class="widget_content">
					<div class="btn_30_dark">
									
									<a href="damageproductdownload"><span class="icon doc_excel_csv_co"></span><span class="btn_link">Download</span></a>
								</div>
						
						<table class="display data_tbl">
						<thead>
						<tr>
							
							<th>
								 Item Name
							</th>
							<th>
								 Damage SL NO
							</th>
							<th>
								 Customer Name
							</th>
							<th>
								 Invoice No
							</th>
							<th>
								 Date
							</th>
							
							
							
							
						</tr>
						</thead>
						<tbody>
						<?php foreach($damageproduct as $s){?>
						<tr class="gradeA">
						<td class="center"><?php echo $s->itemsname;?></td>
						<td class="center"><?php echo $s->slno;?></td>
						<td class="center"><?php echo $s->cname;?></td>						
						<td class="center"><?php echo $s->salesname;?></td>
						<?php
							$damagedate=$s->updated_at;
							$ddate=date_create($damagedate);
						?>
						<td class="center"><?php echo date_format($ddate,"d-m-Y");?></td>
							
						</tr>
						<?php }?>
						
						</tbody>
						
						</table>
					</div>
				</div>
</div></div></div>



@endsection







