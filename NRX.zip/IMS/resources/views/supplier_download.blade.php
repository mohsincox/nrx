
<table>
 <tbody>
  <tr>
   <td>SL NO</td>
   <td>Code</td>
   <td>Name</td>
   <td>Address</td>
   <td>Phone</td>
   <td>Email</td>
   <td>Opening Balance</td>
  </tr>
 <?php
	$i=1;
	foreach($suppliers as $c){
	?>
	<tr>
   <td><?php echo $i; ?></td>
   <td><?php echo $c->code; ?></td>
   <td><?php echo $c->name; ?></td>
   <td><?php echo $c->preaddress; ?></td>
   <td><?php echo $c->phone; ?></td>
   <td><?php echo $c->email; ?></td>
   <td><?php echo $c->openbalance; ?></td>
   <?php 
   $i++;
	}
   ?>
   
  </tr>
  
 </tbody>
</table>