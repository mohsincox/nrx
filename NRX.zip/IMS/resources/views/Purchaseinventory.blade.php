@extends('masterpage')

@section('content')
<div id="content">
<div class="grid_container">

<div class="grid_12">
				<div class="widget_wrap">
					<div class="widget_top">
						<span class="h_icon blocks_images"></span>
						
						<h6>Purchase Inventory</h6>
					</div>
					
					<div class="widget_content">
					<div class="btn_30_dark">
									<a href="purchaseinventory/addnew"><span class="icon add_co"></span><span class="btn_link">Add New Purchase Inventory</span></a>
								</div>
						
						<table class="display data_tbl">
						<thead>
						<tr>
							<th>
								 ID
							</th>
							<th>
								 Items Name
							</th>
							<th>
								 Quantity
							</th>
							<th>
								 Date
							</th>
						</tr>
						</thead>
						<tbody>
						<?php foreach($Purchaseinventory as $p){?>
						<tr class="gradeA">
							<td class="center">
								 <?php echo $p->id;?>
							</td>
							<td class="center">
								<?php echo $p->name;?>
							</td>
							<td class="center">
								<?php echo $p->quantity;?>
							</td>
							<td class="center">
								<?php  $date=date_create($p->created_at); echo date_format($date,"d-m-Y");?>
							</td>
						</tr>
						<?php }?>
						
						</tbody>
						
						</table>
					</div>
				</div>
</div></div></div>

@endsection

