
@extends('masterpage')

@section('content')
<div id="content">
<div class="grid_container">
	<div id="content">
		<div class="grid_container">
			<div class="grid_12 full_block">
				<div class="widget_wrap">
					<div class="widget_top">
						<span class="h_icon list_image"></span>
						<h6>Report On Purchase Inventory</h6>
					</div>
					<form action="purchaseinventoryreport/displayview" method="post" role="form" class="form_container left_label">
	<input type="hidden" name="_token" value="{{ csrf_token() }}">
	<input type="hidden" name="userid" value="{{ Auth::id() }}">
	<ul>
		
		<li>
											<div class="form_grid_12">
								<label class="field_title">Item Name<span class="req">*</span></label>
									<div class="form_input">
									  <select class="chzn-select"   name="itemsid" required > 
										  <?php 
                                            $items_info=DB::table('items')
										 ->join('itemssubgroup', 'itemssubgroup.id', '=', 'items.itemssubgroupid')
                                         ->where('itemssubgroup.itemgroupid','=',2)
										 ->select('items.id','items.name')										 
										 ->get(); 
											echo "<option value='' Selected>Select</option>";
											foreach($items_info as $items){
												
											echo "<option value='".$items->id."' >".$items->name."</option>";
											}?>
											</select>
									</div>
								</div>
		</li>
		
	    <li>
			<div class="form_grid_12">
			<label class="field_title">Today</label>
			<div class="form_input">
			     <button type="submit"  class="btn_small btn_blue" name="submit" value="today"><span>Submit</span></button>
			</div>
			</div>
		</li>
		<li>
			<div class="form_grid_12">
			<label class="field_title">From Date<span class="req">*</span></label>
				<div class="form_input">
					<input name="fromdate" type="datetime" tabindex="1" class="datepicker"  />
				</div>
			</div>
		</li>
		<li>
			<div class="form_grid_12">
			<label class="field_title">To Date<span class="req">*</span></label>
				<div class="form_input">
					<input name="todate" type="datetime" tabindex="1" class="datepicker"  />
				</div>
			</div>
		</li>
		<li>
			<div class="form_grid_12">
				<div class="form_input">
					<button type="submit" class="btn_small btn_blue" name="submit" value="fromdate"><span>Submit</span></button>
				</div>
			</div>
		</li>
	</ul>
	</form>
					
					
				</div>
			</div>
		</div>
		<span class="clear"></span>
	</div></div></div>
@endsection


