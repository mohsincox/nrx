
<table>
 <tbody>
  <tr>
   <td>SL NO</td>
   <td>Code</td>
   <td>Name</td>
   <td>Description</td>
   <td>COA Type</td>
   <td>Increase To</td>
   <td>Tax Rate</td>
  </tr>
 <?php
	$i=1;
	foreach($coa as $c){
	?>
	<tr>
   <td><?php echo $i; ?></td>
   <td><?php echo $c->code; ?></td>
   <td><?php echo $c->name; ?></td>
   <td><?php echo $c->description; ?></td>
   <td><?php echo $c->coatypename; ?></td>
   <td><?php echo $c->increasetypename; ?></td>
   <td><?php echo $c->taxratename; ?></td>
   <?php 
   $i++;
	}
   ?>
   
  </tr>
  
 </tbody>
</table>