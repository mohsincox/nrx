

@extends('masterpage')

@section('content')
<?php
use App\Models\Info;
?>
<div id="content">
<div class="grid_container">
<div class="grid_12">
				<div class="widget_wrap">
					<div class="widget_top">
						<span class="h_icon blocks_images"></span>
						<h6>Report On Purchase Inventory</h6>
						<h6><strong>From Date :</strong> &nbsp;<?php  $date=date_create($fromdate); echo date_format($date,"d/m/Y");?></h6>
						
						<h6><strong>To Date:</strong>&nbsp;<?php  $date=date_create($todate); echo date_format($date,"d/m/Y");?></h6>
					</div>
					<div class="widget_content">
					
						<div class="social_activities">
				<div class="activities_s"  style="background-color:#80B2AC">
					<div class="block_label">
						<a href="reportonpurchase/<?php echo $fromdate;?>/<?php echo $todate;?>/<?php echo $itemsid;?>" target="_blank">Total  Purchase:<span><?php  echo $purchase.' '.$munit;?></span></a>
					</div>
					<span class="badge_icon bank_sl"></span>
				</div>
				<div class="activities_s" style="background-color:#80B2AC">
					<div class="block_label">
						<a href="reportoninventory/<?php echo $fromdate;?>/<?php echo $todate;?>/<?php echo $itemsid;?>" target="_blank">Total Inventory<span><?php echo $inventory.' '.$munit;; ?></span></a>
					</div>
					<span class="badge_icon bank_sl"></span>
				</div>
				<div class="activities_s" style="background-color:#80B2AC">
					<div class="block_label">
						Remaining Quantity<span><?php  echo number_format($purchase-$inventory,2,".","").' '.$munit;; ?></span>
					</div>
					<span class="badge_icon bank_sl"></span>
				</div>
				
				
			</div>
						
						
					</div>
					
				</div>
			
</div></div></div>

@endsection





