<?php
	//print_r($customer_info); die();
 ?>
<table>
 <tbody>
  <tr>
   <th>SL NO</th>
   <th>Customer Name</th>
   <?php
     foreach($item_info as $item){
	   echo '<th>'.$item->iname.'</th>';	 
	 }	 
   ?>
  
  </tr>
 <?php
	$i=1;
	foreach($customer_info as $c){
	?>
	<tr>
	<td><?php echo $i; ?></td>
	<td><?php echo $c->name; ?></td>
     <?php 
     $i++;
	 $ctotal=0;
	foreach($item_info as $item){
		
	 ?>
	 <td>
	 <?php
	     //echo $c->id.','.$item->id..$fdate.$tdate;
		 $count=$sales = DB::table('sales')
				->join('salesdetails', 'salesdetails.salesid', '=', 'sales.id')
				->where('sales.customerid','=',$c->id)
				->where('sales.status','=',1)
				->where('salesdetails.itemid','=',$item->id)
				//->groupBy('salesdetails.itemid')
				->whereBetween('salesdetails.created_at', [$fdate, $tdate])
				->sum('salesdetails.quantity');
		echo $count;
		//$ctotal=$ctotal+$count;
	 ?>
	 </td>
	 <?php
	 }
	}
   ?>
  
  </tr>
  <tr>
	<th></th>
	<th>Total</th>
	<?php
    foreach($item_info as $item){
		
	 ?>
	 <th>
	 <?php
	     //echo $c->id.','.$item->id..$fdate.$tdate;
		 $total_count=$sales = DB::table('sales')
				->join('salesdetails', 'salesdetails.salesid', '=', 'sales.id')
				->where('sales.status','=',1)
				->where('salesdetails.itemid','=',$item->id)
				//->groupBy('salesdetails.itemid')
				->whereBetween('salesdetails.created_at', [$fdate, $tdate])
				->sum('salesdetails.quantity');
		echo $total_count;
		//$ctotal=$ctotal+$count;
	 ?>
	 </th>
	 <?php
	 }  	
	
	?>
  </tr>	
	
 </tbody>
</table>