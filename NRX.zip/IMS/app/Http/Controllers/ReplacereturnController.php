<?php namespace App\Http\Controllers;
use App\Http\Controllers\Common\CommonController;
use App\Http\Controllers\Controller;
use App\Models\Purchase;
use App\Models\Voucher;
use App\Models\Companyprofile;
use App\Models\Physicalsale;
use App\Models\Combo;
use App\Models\Info;
use App\Models\Sale;
use App\Models\Bankaccount;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\Factoryitem;
use PDF;
use DB;
use Auth;
class ReplacereturnController   extends Controller {	
	public function index()
	{
		
		return view('replacereturn');
	}
    public function today(Request $request)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		$date=Combo::callcombo('currentdate');
		//print_r($date);
		foreach($date as $d){
			$curdate=$d->curdate;
		}
		$fromdate=CommonController::date_format($curdate);
		$todate=CommonController::date_format($curdate);
		$fromdate=date("Y-m-d");
		$todate=date("Y-m-d");
		//echo $fromdate.$todate;
		$item_list= DB::table('factioyitems')
		            ->join('sales','factioyitems.salesid','=','sales.id')
					->join('items','factioyitems.itemsid','=','items.id')
					->select('items.name as itemsname','factioyitems.slno','sales.name as salesname','factioyitems.rstatus','factioyitems.dstatus','factioyitems.randno','factioyitems.same_status','sales.id as salesid')
					->orderBy('salesname')
					->where('factioyitems.rstatus',1)
					->orWhere('factioyitems.dstatus',1)
					->whereBetween('factioyitems.updated_at',array($fromdate,$todate)) 
		            ->get();
        //print_r($item_list); die();	
		$pdate=date_create($fromdate);
		$sdate=date_create($todate);
		
			$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$cid=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
	}
	
	
			PDF::AddPage();
			$html1='
			
			<p></p>
					<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>	
					</div>
			

<div>

<h3>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<u>Reports on Replace Return</h3></u></div>
<div><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; From Date:'.date_format($pdate,"d-m-Y").' &nbsp;&nbsp;&nbsp;&nbsp; To Date:'.date_format($sdate,"d-m-Y").'</strong></div></div>
<table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%">Serial No.</th>
				<th>Item Name</th>
				<th>Serial No</th>
				<th>Invoice No</th>
				<th>Status</th>
				
			  </tr>';
			  
		$html2= '';
		$i=1;
		//$total=0.00;
		foreach($item_list as $valu){ 
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'</td>
			    <td style="background-color:#ffffff;">'.$valu->itemsname.'</td>
				<td style="background-color:#ffffff;">'.$valu->slno.'</td>
				<td style="background-color:#ffffff;"><a href="http://192.168.1.3/IMS/physicalsales/print/'.$valu->salesid.'"   target="_blank">'.$valu->salesname.'</a></td>';
				if($valu->rstatus==1){
				$h1='<td style="background-color:#ffffff;">New Return</td>';
				}
				if($valu->dstatus==1){
				$h1='<td style="background-color:#ffffff;">Demage Product</td>';
				}
				
				if($valu->same_status==1){
				$h1='<td style="background-color:#ffffff;">Sales Return</td>';
				}
				$h2='</tr>';
				$html=$html.$h1.$h2;
				$html2=$html2.$html;
				$i++;
				//$total=$total+$valu->amount;
		} 			
		$html3='</table></div>
		
                        <div></div><div></div><div></div><div>	
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		    PDF::Output('ReplaceReturnReport.pdf');
	}
	public function fromtoday(Request $request)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		$fromdate=CommonController::date_format($request->input('fromdate'));
		$todate=CommonController::date_format($request->input('todate')); 
        $item_list= DB::table('factioyitems')
		            ->join('sales','factioyitems.salesid','=','sales.id')
					->join('items','factioyitems.itemsid','=','items.id')
					->select('items.name as itemsname','factioyitems.slno','sales.name as salesname','factioyitems.rstatus','factioyitems.dstatus','factioyitems.randno','factioyitems.same_status','sales.id as salesid')
					->orderBy('salesname')
					->where('factioyitems.rstatus',1)
					->orWhere('factioyitems.dstatus',1)
					->whereBetween('factioyitems.updated_at',array($fromdate,$todate)) 
		            ->get();
        //print_r($item_list); die();	
		$pdate=date_create($fromdate);
		$sdate=date_create($todate);	
			$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$cid=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
	}
	
	
			PDF::AddPage();
			$html1='
			
			<p></p>
					<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>	
					</div>
			

<div>

<h3>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<u>Reports on Replace Return</h3></u></div>
<div><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; From Date:'.date_format($pdate,"d-m-Y").' &nbsp;&nbsp;&nbsp;&nbsp; To Date:'.date_format($sdate,"d-m-Y").'</strong></div></div>
<table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%">Serial No.</th>
				<th>Item Name</th>
				<th>Serial No</th>
				<th>Invoice No</th>
				<th>Status</th>
				
			  </tr>';
			  
		$html2= '';
		$i=1;
		//$total=0.00;
		foreach($item_list as $valu){ 
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'</td>
			    <td style="background-color:#ffffff;">'.$valu->itemsname.'</td>
				<td style="background-color:#ffffff;">'.$valu->slno.'</td>
				<td style="background-color:#ffffff;"><a href="http://192.168.1.3/IMS/physicalsales/print/'.$valu->salesid.'"   target="_blank">'.$valu->salesname.'</a></td>';
				if($valu->rstatus==1){
				$h1='<td style="background-color:#ffffff;">New Return</td>';
				}
				if($valu->dstatus==1){
				$h1='<td style="background-color:#ffffff;">Demage Product</td>';
				}
				
				if($valu->same_status==1){
				$h1='<td style="background-color:#ffffff;">Sales Return</td>';
				}
				$h2='</tr>';
				$html=$html.$h1.$h2;
				$html2=$html2.$html;
				$i++;
				//$total=$total+$valu->amount;
		} 			
		$html3='</table></div>
		
				<div></div><div></div><div></div><div>
					<table border="0" style="width:110%">
								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		    PDF::Output('ReplaceReturnReport.pdf');

}
}
