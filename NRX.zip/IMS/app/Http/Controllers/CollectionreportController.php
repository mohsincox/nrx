<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Companyprofile;
use App\Models\Info;
use App\Models\Combo;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Common\CommonController;
use Session;
use PDF;
use DB;
use Auth;

class CollectionreportController  extends Controller {
	
	public function __construct()
	{
		$this->middleware('auth');
		$permission = \App\Http\Controllers\Common\CommonController::check_permission('collectionreport');
		if($permission == 0){
			echo 'This url is not found.';die();
			return redirect('/home');
		}
	}
	
	public function index()
	{
		
		return view('collectionreport');
		

	}
	

     public function today(Request $request)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
	
		
		$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		 $spname="todaycollection";
		$c=Combo::callcombo($spname);
		$spname3="todaycash";
		$c5=Combo::callcombo($spname3);
		$spname4="todaybankcollection";
		$c6=Combo::callcombo($spname4);
		$spname5="todaycashcollection";
		$c7=Combo::callcombo($spname5);
		$spname6="todaybkashcollection";
		$c8=Combo::callcombo($spname6);
		$spsap="todaysapcollection";
		$csap=Combo::callcombo($spsap);
		$spkcs="todaykcscollection";
		$ckcs=Combo::callcombo($spkcs);
		$spmbank="todaymbankcollection";
		$cmbank=Combo::callcombo($spmbank);
	foreach($c6 as $cc){ $totalbankcash=$cc->cash;}
	foreach($c7 as $ccc){ $totalhandcash=$ccc->cash;}
	foreach($c8 as $ccc){ $totalbkash=$ccc->cash;}	
	foreach($csap as $ccc){ $totalsap=$ccc->cash;}	
	foreach($ckcs as $ccc){ $totalkcs=$ccc->cash;}	
	foreach($cmbank as $ccc){ $totalmbank=$ccc->cash;}	
		$sum=0;
		foreach($c as $p){ 
				$a=$p->amount;	
				$sum=$sum+$a;
		} 
		
		PDF::AddPage('L');
		 
		$html1='
			<p></p>
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
						
						<h2>
					    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<u>Statement of Collection</u></h2><h4><br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						Date: '. date("d-m-Y") .'  To  '. date("d-m-Y") .'</h4>
						</div>
						
				<table border="1" style="background-color:lightblue; width:100%; padding:20px;">	
					<tr>
						<th style="width:3%;">SL</th>
						<th style="width:10%;">Name</th>
						<th style="width:12%;">Present Address</th>
						<th style="width:7%;">Voucher No.</th>
						<th>Bank Amount</th>
						<th>Cash</th>
						<th>BKash</th>
						<th>SAP</th>
						<th>KCS</th>
						<th>MBank</th>
						<th>Total Cash</th>
						<th>Grand Total</th>
					</tr>';
				
		$html2= '';
		 $i=1;
		 $sum=0;
		$grand_total_cash=0.00;
		foreach($c as $p){ 
		        if($p->type==3){
					$bankamount=$p->amount;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==4){
					$bankamount=0.00;
					$cashamount=$p->amount;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==6){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=$p->amount;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==7){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=$p->amount;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==8){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=$p->amount;
					$mbank=0.00;
				}else if($p->type==9){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=$p->amount;
				}
				$totalcash=$cashamount+$bkash+$sap+$kcs+$mbank;
				$html='<tr><td style="background-color:#ffffff;">'.$i.'</td>
				<td style="background-color:#ffffff;">'.$p->name.'</td>
				<td style="background-color:#ffffff;">'.$p->preaddress.'</td>
				<td style="background-color:#ffffff;"><a href="http://192.168.1.8/IMS/voucher/pdf/'.$p->id.'/'.$p->type.'"   target="_blank">'.$p->vnno.'</a></td>					
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bankamount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($cashamount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bkash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($sap, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($kcs, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($mbank, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($p->amount, 2, '.', '')).'</td>
				</tr>';
				$html2=$html2.$html;
				$i++;
				$sum=$sum+$p->amount;
				$grand_total_cash=$grand_total_cash+$totalcash;
		} 
		$html3='<tr><td colspan="4" align="right" style="background-color:#ffffff;">';
		$html4='';
		$html5='Total:</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalbankcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalhandcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalbkash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalsap, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalkcs, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalmbank, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($grand_total_cash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($sum, 2, '.', '')).'</td></tr>';
		$html6='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($sum, 2, '.', '')).' Taka Only</h4></div>
						<div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3.$html4.$html5.$html6;
		
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('collection.pdf');
	}
	
	 public function fromtoday(Request $request)
	{
		$fromdate=CommonController::date_format($request->input('fromdate'));
			$todate=CommonController::date_format($request->input('todate'));
			
            $var = array($fromdate,$todate);
		
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
	
		
		$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		
		$spname="fromtodaycollection";
		$c=Info::callinfo($var,$spname);
		//print_r($c);die();
		$spname3="fromtodaycash";
		$c5=Info::callinfo($var,$spname3);
		
		$spname4="fromtodaybankcollection";
		$c6=Info::callinfo($var,$spname4);
		
		$spname5="fromtodaycashcollection";
		$c7=Info::callinfo($var,$spname5);
		
		$spname6="fromtodaybkashcollection";
		$c8=Info::callinfo($var,$spname6);
		
		$spsap="fromtodaysapcollection";
		$csap=Info::callinfo($var,$spsap);
		//print_r($csap);die();
		$spkcs="fromtodaykcscollection";
		$ckcs=Info::callinfo($var,$spkcs);
		
		$spmbank="fromtodaymbankcollection";
		$cmbank=Info::callinfo($var,$spmbank);
		//print_r($cmbank);die();
	//foreach($c6 as $cc){ $totalbankcash=$cc->cash;}
	//foreach($c7 as $ccc){ $totalhandcash=$ccc->cash;}
	//foreach($c8 as $ccc){ $totalbkash=$ccc->cash;}	
	//foreach($csap as $ccc){ $totalsap=$ccc->cash;}	
	//foreach($ckcs as $ccc){ $totalkcs=$ccc->cash;}	
	//foreach($cmbank as $ccc){ $totalmbank=$ccc->cash;}	

	$totalbankcash=DB::table('voucher')
	              ->where('vstatus',1)
				  ->where('type',3)
				  ->whereBetween('created_at',array($fromdate,$todate))
				  ->sum('amount');
				  
	
	$totalhandcash=DB::table('voucher')
	              ->where('vstatus',1)
				  ->where('type',4)
				  ->whereBetween('created_at',array($fromdate,$todate))
				  ->sum('amount');
				  
	$totalbkash=DB::table('voucher')
	              ->where('vstatus',1)
				  ->where('type',6)
				  ->whereBetween('created_at',array($fromdate,$todate))
				  ->sum('amount');
				  
	$totalsap=DB::table('voucher')
	              ->where('vstatus',1)
				  ->where('type',7)
				  ->whereBetween('created_at',array($fromdate,$todate))
				  ->sum('amount');	
    //print_r($totalsap);die();
	$totalkcs=DB::table('voucher')
	              ->where('vstatus',1)
				  ->where('type',8)
				  ->whereBetween('created_at',array($fromdate,$todate))
				  ->sum('amount');

	$totalmbank=DB::table('voucher')
	              ->where('vstatus',1)
				  ->where('type',9)
				  ->whereBetween('created_at',array($fromdate,$todate))
				  ->sum('amount');
	//echo $totalbankcash.'<br>'; 
	//echo $totalhandcash.'<br>'; 
	//echo $totalbkash.'<br>'; 
	//echo $totalsap.'<br>'; 
	//echo $totalkcs.'<br>'; 
	//echo $totalmbank.'<br>'; 
	
	//die();			  
	//	foreach($c as $p){ 
	//			$a=$p->amount;	
	//			$sum=$sum+$a;
	//	} 
		$pdate=date_create($fromdate);
		$sdate=date_create($todate);
		PDF::AddPage('L');
		 
		$html1='
			<p></p>
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
						
						<h2>
					    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<u>Statement of Collection</u></h2><h4><br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						Date: '.date_format($pdate,"d-m-Y").'  To  '.date_format($sdate,"d-m-Y").'</h4>
						</div>
						
				<table border="1" style="background-color:lightblue; width:100%; padding:20px;">	
					<tr>
						<th style="width:3%;">SL</th>
						<th style="width:10%;">Name</th>
						<th style="width:12%;">Present Address</th>
						<th style="width:7%;">Voucher No.</th>
						<th>Bank Amount</th>
						<th>Cash</th>
						<th>BKash</th>
						<th>SAP</th>
						<th>KCS</th>
						<th>MBank</th>
						<th>Total Cash</th>
						<th>Grand Total</th>
					</tr>';
				
		$html2= '';
		 $i=1;
		 $sum=0;
		$grand_total_cash=0.00;
		foreach($c as $p){ 
		        if($p->type==3){
					$bankamount=$p->amount;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==4){
					$bankamount=0.00;
					$cashamount=$p->amount;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==6){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=$p->amount;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==7){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=$p->amount;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==8){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=$p->amount;
					$mbank=0.00;
				}else if($p->type==9){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=$p->amount;
				}
				$totalcash=$cashamount+$bkash+$sap+$kcs+$mbank;
				$html='<tr><td style="background-color:#ffffff;">'.$i.'</td>
				<td style="background-color:#ffffff;">'.$p->name.'</td>
				<td style="background-color:#ffffff;">'.$p->preaddress.'</td>
				<td style="background-color:#ffffff;"><a href="http://192.168.1.8/IMS/voucher/pdf/'.$p->id.'/'.$p->type.'"   target="_blank">'.$p->vnno.'</a></td>					
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bankamount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($cashamount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bkash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($sap, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($kcs, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($mbank, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($p->amount, 2, '.', '')).'</td>
				</tr>';
				$html2=$html2.$html;
				$i++;
				$sum=$sum+$p->amount;
				$grand_total_cash=$grand_total_cash+$totalcash;
		} 
		$html3='<tr><td colspan="4" align="right" style="background-color:#ffffff;">';
		$html4='';
		$html5='Total:</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalbankcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalhandcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalbkash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalsap, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalkcs, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalmbank, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($grand_total_cash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($sum, 2, '.', '')).'</td></tr>';
		$html6='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($sum, 2, '.', '')).' Taka Only</h4></div>
						<div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3.$html4.$html5.$html6;
		
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('collection.pdf');
	}
	
	
}
