<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Bankaccount;
use App\Models\Vouchercontra;
use App\Models\Voucher;
use App\Models\Supplier;
use App\Models\Companyprofile;
use App\Models\Info;
use App\Models\Bankbook;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Common\CommonController;
use DB;
use PDF;
use Auth;
class Database_backupController   extends Controller {

	public function __construct()
	{
		$this->middleware('auth');
		$permission = \App\Http\Controllers\Common\CommonController::check_permission('database_backup');
		if($permission == 0){
			echo 'This url is not found.';die();
			return redirect('/home');
		}
	}

	public function index()
	{
		ob_start();				 
		$username = "root"; 
		$password = ""; 
		$hostname = "localhost"; 
		$dbname   = "ims";					
		$command = "C:\\xampp\\mysql\\bin\\mysqldump --add-drop-table --host=$hostname --user=$username ";
		if ($password) 
		$command.= "--password=". $password ." "; 
		$command.= $dbname;
		system($command);					 
		$dump = ob_get_contents(); 
		ob_end_clean();
		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.basename($dbname . "_" . 
		date("Y-m-d_H-i-s").".sql"));
		flush();
		echo $dump;
		exit();

	}

	
	
}
