<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Info;
use App\Models\Combo;
use App\Models\Companyprofile;
use App\Http\Controllers\Common\CommonController;
use App\Http\Requests;
use Illuminate\Http\Request;
use PDF;
use DB;
use Auth;

class ReportpurchaseinventoryController   extends Controller {
	
	public function __construct()
	{
		$this->middleware('auth');
		$permission = \App\Http\Controllers\Common\CommonController::check_permission('purchaseinventoryreport');
		if($permission == 0){
			echo 'This url is not found.';
			return redirect('/home');
		}
	}
	
	public function index()
	{
		
		return view('purchaseinventoryreport');
		

	}
	public function addnew()
	{
		
		//return view('createphysicalsale');
	}

    public function displayview(Request $request)
	{
	        $submitdate=$request->input('submit');
			if($submitdate=='today'){
				$itemsid=$request->input('itemsid');
				$date=Combo::callcombo('currentdate');
				//print_r($date);
				foreach($date as $d){
					$curdate=$d->curdate;
				}
				$fromdate=CommonController::date_format($curdate);
				$todate=CommonController::date_format($curdate);
				$fromdate=date("Y-m-d");
				$todate=date("Y-m-d");
				$var = array($itemsid,$fromdate,$todate);
				    $m_unit=DB::table('items')
					        ->join('measurementunit', 'measurementunit.id', '=', 'items.mesid')
							->select('measurementunit.name')
							->first();
					$munit=$m_unit->name;		
					$purchase=DB::table('purchasedetails')
					          ->where('itemid',$itemsid)
					          ->wherebetween('created_at',array($fromdate,$todate))
							  ->sum('quantity');
					$inventory=DB::table('purchaseinventory')
					           ->where('itemsid',$itemsid)
					           ->wherebetween('created_at',array($fromdate,$todate))
							   ->sum('quantity');
					return view('purchasereportview', compact('purchase','inventory','fromdate','todate','munit','itemsid'));
				
			}else if($submitdate=='fromdate'){ 
			    $itemsid=$request->input('itemsid');
				$fromdate=CommonController::date_format($request->input('fromdate'));
				$todate=CommonController::date_format($request->input('todate'));
			    $var = array($itemsid,$fromdate,$todate);
				$var = array($itemsid,$fromdate,$todate);
				    $m_unit=DB::table('items')
					        ->join('measurementunit', 'measurementunit.id', '=', 'items.mesid')
							->select('measurementunit.name')
							->first();
					$munit=$m_unit->name;		
					$purchase=DB::table('purchasedetails')
					          ->where('itemid',$itemsid)
					          ->wherebetween('created_at',array($fromdate,$todate))
							  ->sum('quantity');
					$inventory=DB::table('purchaseinventory')
					           ->where('itemsid',$itemsid)
					           ->wherebetween('created_at',array($fromdate,$todate))
							   ->sum('quantity');
					return view('purchasereportview', compact('purchase','inventory','fromdate','todate','munit','itemsid'));
				
			}            
	}
	
	public function reportonpurchase(Request $request,$fromdate,$todate,$itemsid)
	{
		$purchase=DB::table('purchasedetails')
		          ->join('purchase', 'purchase.id', '=', 'purchasedetails.purchaseid')
                  ->join('items', 'items.id', '=', 'purchasedetails.itemid')				  
				  ->where('itemid',$itemsid)
				  ->wherebetween('purchasedetails.created_at',array($fromdate,$todate))
				  ->select('purchase.id as pid','purchase.name as pname','items.name as iname','purchasedetails.quantity as quantity','purchasedetails.created_at')
				  ->get();
		//print_r($purchase);	die();
        //pdf report
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		$profile=Companyprofile::get();
		//print_r($profile);
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		
			PDF::AddPage();
			$html1=' 
		<p></p>
					<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>	
					</div>

<div>

<h3>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<u>Purchase Analyst</h3></u>
<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							From	'.date('d-m-Y', strtotime($fromdate)).'&nbsp;To&nbsp;'.date('d-m-Y', strtotime($todate)).'</h4>
					</div>
<table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%">&nbsp;&nbsp;&nbsp;&nbsp;ID</th>
				<th>Purchase Name</th>
				<th>Items Name</th>
				<th style="width:20%">Date</th>
				<th style="width:20%">Quantity</th>
			  </tr>';	  
		$html2= '';
		$i=1;
		$sum=0;
		foreach($purchase as $p){ 
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'</td>
				<td style="background-color:#ffffff;"><a href="http://192.186.247.183/IMS/purchase/pdf/'.$p->pid.'"   target="_blank">'.$p->pname.'</a></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.$p->iname.'</td>
				<td style="background-color:#ffffff;">'.date('d-m-Y', strtotime($p->created_at)).'</td>			
				<td style="background-color:#ffffff;">'.$p->quantity.'</td></tr>';
				$html2=$html2.$html;
				$i++;
				$sum=$sum+$p->quantity;
		} 			
		$html3='<tr><td style="background-color:#ffffff;" colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total</td>
		<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($sum,2,".","")).'</td></tr></table></div>
		
					<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		    PDF::Output('purchase.pdf');
		
		
		//pdf report
		
	}
	public function reportoninventory(Request $request,$fromdate,$todate,$itemsid)
	{
		$inventory=DB::table('purchaseinventory')
		           ->join('items', 'items.id', '=', 'purchaseinventory.itemsid')
				   ->join('users', 'users.id', '=', 'purchaseinventory.userid')
				   ->where('itemsid',$itemsid)
				   ->wherebetween('purchaseinventory.created_at',array($fromdate,$todate))
				   ->select('items.name as iname','purchaseinventory.quantity as quantity','users.name as uname','purchaseinventory.created_at')
				   ->get();
		//print_r($inventory);
		
		//pdf report
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		$profile=Companyprofile::get();
		//print_r($profile);
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		
			PDF::AddPage();
			$html1=' 
		<p></p>
					<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>	
					</div>

<div>

<h3>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<u>Purchase Analyst</h3></u>
<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							From	'.date('d-m-Y', strtotime($fromdate)).'&nbsp;To&nbsp;'.date('d-m-Y', strtotime($todate)).'</h4>
					</div>
<table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%">&nbsp;&nbsp;&nbsp;&nbsp;ID</th>
				<th>Items Name</th>
				<th>User Name</th>
				<th style="width:20%">Date</th>
				<th style="width:20%">Quantity</th>
			  </tr>';	  
		$html2= '';
		$i=1;
		$sum=0;
		foreach($inventory as $in){ 
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'</td>
				<td style="background-color:#ffffff;">'.$in->iname.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.$in->uname.'</td>
				<td style="background-color:#ffffff;">'.date('d-m-Y', strtotime($in->created_at)).'</td>			
				<td style="background-color:#ffffff;">'.$in->quantity.'</td></tr>';
				$html2=$html2.$html;
				$i++;
				$sum=$sum+$in->quantity;
		} 			
		$html3='<tr><td style="background-color:#ffffff;" colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td><td style="background-color:#ffffff;">'.number_format($sum,2,".","").'</td></tr></table></div>
		
					<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		    PDF::Output('inventory.pdf');
		
		
		//pdf report
		
	}
	
	
}
