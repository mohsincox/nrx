<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Info;
use App\Models\Combo;
use App\Models\Companyprofile;
use App\Http\Controllers\Common\CommonController;
use App\Http\Requests;
use Illuminate\Http\Request;
use PDF;
use DB;
use Auth;
class CashController extends Controller {
public function index()
	{
		
		return view('cashbook');
		

	}
	

     public function today(Request $request)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		//echo substr('V-9999999',0,1);die();
				$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$cid=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
	        $date=Combo::callcombo('currentdate');
			//print_r($date);
			foreach($date as $d){
				$curdate=$d->curdate;
			}
			$fromdate=CommonController::date_format($curdate);
            $todate=CommonController::date_format($curdate);
			$fromdate=date("Y-m-d");
            $todate=date("Y-m-d");
            $var = array($fromdate,$todate);
            $spname="rptcash";
            $value=Info::callinfo($var,$spname);
			//print_r($value);
			//die();
			
			foreach($value as $valu){ 
					$id=$valu->id;
					$amount=$valu->amount;
		
		    }
			//print_r($value);die();
			$var1=array($todate);
			//print_r($var1);die();
			$spname1="totalcashcollection";
			$value1=Info::callinfo($var1,$spname1);
			$voucher_receive=DB::table('voucher')
			                ->whereIn('type', [4,6,7,8,9])
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');
			$voucher_payment=DB::table('voucher')
			                ->where('type',2)
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');
			$pettycash_receive=DB::table('pettycash')
			                ->join('coa', 'coa.id', '=','pettycash.particular')
			                ->where('coa.increasetypeid',2)
							->where('pettycash.created_at','<',$fromdate)
							->sum('pettycash.amount');				
            $pettycash_payment=DB::table('pettycash')
			                ->join('coa', 'coa.id', '=','pettycash.particular')
			                ->where('coa.increasetypeid',1)
							->where('pettycash.created_at','<',$fromdate)
							->sum('pettycash.amount');	
            $contra_receive=DB::table('voucher')
			                ->where('type',5)
							->where('status',1)
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');
			$contra_payment=DB::table('voucher')
			               ->where('type',5)
							->where('status',2)
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');							
			//echo $voucher_payment; die();	
          	$opening_balance=$voucher_receive-$voucher_payment+$pettycash_receive-$pettycash_payment+$contra_receive-$contra_payment;	
			$coa = DB::table('coa')->where('id',1)->first();
			$coabalance=$coa->openbalance;
			//echo $coabalance;
            $openbalance=$opening_balance+$coabalance;
		    $pdate=date_create($fromdate);
			$sdate=date_create($todate);
			PDF::AddPage('A4');
			$html1='
			
			<p></p>
					<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>	
					</div>
			

<div>

<h3>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<u>Cash A/C Book</h3></u></div>
<div><strong> From Date:'.date_format($pdate,"d-m-Y").' &nbsp;&nbsp;&nbsp;&nbsp; To Date:'.date_format($sdate,"d-m-Y").' </strong></div></div>
<table border="1" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;Date</th>
				<th>Particulars</th>
				<th>Vch Type</th>
				<th>Vch No</th>
				<th>Debit</th>
				<th>Credit</th>
				<th>Balance</th>
			  </tr>
			  <tr>
				<td colspan="6" style="background-color:#ffffff;">Opening Balance</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($openbalance, 2, '.', '')).'</td>
			  </tr>';
			  
		$html2= '';
		$i=1;
		$dtotal=0;
		$ctotal=0;
		$bamount=$openbalance;
		foreach($value as $valu){ 
		        if(substr($valu->vnno,0,1)=='V'){
					//$vnno='Voucher';
					$voucher = DB::table('voucher')->where('id',$valu->id)->first();
					if($voucher->type==2){
					   $vnno='Cash Payment A/C';
					   $type='Payment';
					   $damount=NULL;
					   $camount=$valu->amount;
					   $bamount=$bamount-$valu->amount;
					   $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;
					}else if($voucher->type==4){
					   $vnno='Cash Collection A/C'; 
                       $type='Receipt'; 
					   $damount=$valu->amount;
					   $bamount=$bamount+$valu->amount;
                       $camount=NULL;
						$link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type; 					   
					}else if($voucher->type==5){
						if($voucher->status==1){
						   $vnno='Cash Contra  A/C'; 
						   $type='Receipt Contra';
                           $damount=$valu->amount;
						   $bamount=$bamount+$valu->amount;						   
                           $camount=NULL;	
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;  						   
                        }					   
						else if($voucher->status==2){
							 $vnno='Bank Contra A/C';
							 $type='Payment  Contra';
                             $damount=NULL;
                             $camount=$valu->amount;
							 $bamount=$bamount-$valu->amount;
                             $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;							 
						}
					  
					}
					else if($voucher->type==6){
					   $vnno='bKash Collection A/C';
                       $coa = DB::table('coa')->where('id',4)->first();
                       if($coa->increasetypeid==1){
						  $type='Receipt';  
						  $damount=$valu->amount;
						  $bamount=$bamount+$valu->amount;
						  $camount=NULL;
						  $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;
					   }else if($coa->increasetypeid==2){
						   $type='Payment';  
						   $damount=NULL;
						   $camount=$valu->amount;
						   $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;
					   } 					   
					}else if($voucher->type==7){
					   $vnno='SAP Collection A/C';
                       $coa = DB::table('coa')->where('id',5)->first();					   
                       if($coa->increasetypeid==1){
						  $type='Receipt';
                          $damount=$valu->amount;
						  $bamount=$bamount+$valu->amount;
                          $camount=NULL;
                          $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type; 						  
					   }else if($coa->increasetypeid==2){
						   $type='Payment'; 
						   $damount=NULL;
                           $camount=$valu->amount;
						   $bamount=$bamount+$valu->amount;
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						   
					   }    					   
					}else if($voucher->type==8){
					   $vnno='KCS Collection A/C';
					   $coa = DB::table('coa')->where('id',6)->first();
                       if($coa->increasetypeid==1){
						  $type='Receipt';
                          $damount=$valu->amount;
                          $camount=NULL;
						  $bamount=$bamount+$valu->amount;
                          $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						  
					   }else if($coa->increasetypeid==2){
						   $type='Payment'; 
						   $camount=$valu->amount;
						   $bamount=$bamount-$valu->amount;
                           $damount=NULL;
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						   
					   } 					   
					}else if($voucher->type==9){
					   $vnno='MBank Collection A/C';
					   $coa = DB::table('coa')->where('id',7)->first(); 
                       if($coa->increasetypeid==1){
						  $type='Receipt';
                          $damount=$valu->amount;
						  $bamount=$bamount+$valu->amount;
                          $camount=NULL;
                          $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						  
					   }else if($coa->increasetypeid==2){
						   $type='Payment'; 
                           $camount=$valu->amount;
						   $bamount=$bamount-$valu->amount;
                           $damount=NULL; 
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						   
					   }  					   
					}
				}else{
					$pettycash = DB::table('pettycash')->where('id',$valu->id)->first();				
					$coa = DB::table('coa')->where('id',$pettycash->particular)->first();
					$vnno=$coa->name;
					//echo $vnno;
					if($coa->increasetypeid==2){
						  $type='Receipt'; 
                          $damount=$valu->amount;
                          $camount=NULL;
                          $bamount=$bamount+$valu->amount; 						  
					   }else if($coa->increasetypeid==1){
						   $type='Payment';
						   $damount=NULL;
                           $camount=$valu->amount;	
                           $bamount=$bamount-$valu->amount;						   
					   }  
					 $link='http://192.168.1.8/IMS/ledgerentry/pdf/'.$valu->id;  
				}
				$html='<tr><td style="background-color:#ffffff;">&nbsp;'.date('d-m-Y', strtotime($valu->created_at)).'</td>
			    <td style="background-color:#ffffff;">'.$vnno.'</td>
				<td style="background-color:#ffffff;">'.$type.'</td>
				<td style="background-color:#ffffff;"><a href="'.$link.'">'.$valu->vnno.'</a></td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($damount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($camount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bamount, 2, '.', '')).'</td>
				</tr>';
				$html2=$html2.$html;
				$i++;
				$dtotal=$dtotal+$damount;
		        $ctotal=$ctotal+$camount;
		} 			
		$html3='<tr>
				<td colspan="4" >Total</td>
				<td>'.CommonController::convertmoneyformat(number_format($dtotal, 2, '.', '')).'</td>
				<td>'.CommonController::convertmoneyformat(number_format($ctotal, 2, '.', '')).'</td>
				<td>'.CommonController::convertmoneyformat(number_format($bamount, 2, '.', '')).'</td>
			  </tr>
		</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($bamount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		    PDF::Output('cash.pdf');


		
            
	}
	
	 public function fromtoday(Request $request)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$cid=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
	       
			$fromdate=CommonController::date_format($request->input('fromdate'));
			$todate=CommonController::date_format($request->input('todate'));
            $var = array($fromdate,$todate);
            $spname="rptcash";
            $value=Info::callinfo($var,$spname);
			//print_r($value);
			//die();
			
			foreach($value as $valu){ 
					$id=$valu->id;
					$amount=$valu->amount;
		
		    }
			//print_r($value);die();
			$var1=array($todate);
			//print_r($var1);die();
			$spname1="totalcashcollection";
			$value1=Info::callinfo($var1,$spname1);
			//print_r($value1);die();
			foreach($value1 as $valu){ 
					//$id=$valu->id;
					$opening_balance=$valu->cash;
		
		    }
			$voucher_receive=DB::table('voucher')
			                ->whereIn('type', [4,6,7,8,9])
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');
			$voucher_payment=DB::table('voucher')
			                ->where('type',2)
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');
			$pettycash_receive=DB::table('pettycash')
			                ->join('coa', 'coa.id', '=','pettycash.particular')
			                ->where('coa.increasetypeid',2)
							->where('pettycash.created_at','<',$fromdate)
							->sum('pettycash.amount');				
            $pettycash_payment=DB::table('pettycash')
			                ->join('coa', 'coa.id', '=','pettycash.particular')
			                ->where('coa.increasetypeid',1)
							->where('pettycash.created_at','<',$fromdate)
							->sum('pettycash.amount');	
            $contra_receive=DB::table('voucher')
			                ->where('type',5)
							->where('status',1)
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');
			$contra_payment=DB::table('voucher')
			               ->where('type',5)
							->where('status',2)
							->where('created_at','<',$fromdate)
							->where('vstatus','=',1)
							->sum('amount');							
			//echo $voucher_payment; die();	
          	$opening_balance=$voucher_receive-$voucher_payment+$pettycash_receive-$pettycash_payment+$contra_receive-$contra_payment;		
			$coa = DB::table('coa')->where('id',1)->first();
			$coabalance=$coa->openbalance;
			//echo $coabalance;
            $openbalance=$opening_balance+$coabalance;
			$pdate=date_create($fromdate);
		    $sdate=date_create($todate);
			PDF::AddPage('A4');
			$html1='
			
			<p></p>
					<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>	
					</div>
			

<div>

<h3>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<u>Cash A/C Book</h3></u></div>
<div><strong> From Date:'.date_format($pdate,"d-m-Y").' &nbsp;&nbsp;&nbsp;&nbsp; To Date:'.date_format($sdate,"d-m-Y").' </strong></div></div>
<table border="1" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;Date</th>
				<th>Particulars</th>
				<th>Vch Type</th>
				<th>Vch No</th>
				<th>Debit</th>
				<th>Credit</th>
				<th>Balance</th>
			  </tr>
			  <tr>
				<td colspan="6" style="background-color:#ffffff;">Opening Balance</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($openbalance, 2, '.', '')).'</td>
			  </tr>';
			  
		$html2= '';
		$i=1;
		$dtotal=0;
		$ctotal=0;
		$bamount=$openbalance;
		foreach($value as $valu){ 
		        if(substr($valu->vnno,0,1)=='V'){
					//$vnno='Voucher';
					$voucher = DB::table('voucher')->where('id',$valu->id)->first();
					if($voucher->type==2){
					   $vnno='Cash Payment A/C';
					   $type='Payment';
					   $damount=NULL;
					   $camount=$valu->amount;
					   $bamount=$bamount-$valu->amount;
					   $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;
					}else if($voucher->type==4){
					   $vnno='Cash Collection A/C'; 
                       $type='Receipt'; 
					   $damount=$valu->amount;
					   $bamount=$bamount+$valu->amount;
                       $camount=NULL;
						$link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type; 					   
					}else if($voucher->type==5){
						if($voucher->status==1){
						   $vnno='Cash Contra  A/C'; 
						   $type='Receipt Contra';
                           $damount=$valu->amount;
						   $bamount=$bamount+$valu->amount;						   
                           $camount=NULL;	
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;  						   
                        }					   
						else if($voucher->status==2){
							 $vnno='Bank Contra A/C';
							 $type='Payment  Contra';
                             $damount=NULL;
                             $camount=$valu->amount;
							 $bamount=$bamount-$valu->amount;
                             $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;							 
						}
					  
					}
					else if($voucher->type==6){
					   $vnno='bKash Collection A/C';
                       $coa = DB::table('coa')->where('id',4)->first();
                       if($coa->increasetypeid==1){
						  $type='Receipt';  
						  $damount=$valu->amount;
						  $bamount=$bamount+$valu->amount;
						  $camount=NULL;
						  $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;
					   }else if($coa->increasetypeid==2){
						   $type='Payment';  
						   $damount=NULL;
						   $camount=$valu->amount;
						   $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;
					   } 					   
					}else if($voucher->type==7){
					   $vnno='SAP Collection A/C';
                       $coa = DB::table('coa')->where('id',5)->first();					   
                       if($coa->increasetypeid==1){
						  $type='Receipt';
                          $damount=$valu->amount;
						  $bamount=$bamount+$valu->amount;
                          $camount=NULL;
                          $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type; 						  
					   }else if($coa->increasetypeid==2){
						   $type='Payment'; 
						   $damount=NULL;
                           $camount=$valu->amount;
						   $bamount=$bamount+$valu->amount;
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						   
					   }    					   
					}else if($voucher->type==8){
					   $vnno='KCS Collection A/C';
					   $coa = DB::table('coa')->where('id',6)->first();
                       if($coa->increasetypeid==1){
						  $type='Receipt';
                          $damount=$valu->amount;
                          $camount=NULL;
						  $bamount=$bamount+$valu->amount;
                          $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						  
					   }else if($coa->increasetypeid==2){
						   $type='Payment'; 
						   $camount=$valu->amount;
						   $bamount=$bamount-$valu->amount;
                           $damount=NULL;
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						   
					   } 					   
					}else if($voucher->type==9){
					   $vnno='MBank Collection A/C';
					   $coa = DB::table('coa')->where('id',7)->first(); 
                       if($coa->increasetypeid==1){
						  $type='Receipt';
                          $damount=$valu->amount;
						  $bamount=$bamount+$valu->amount;
                          $camount=NULL;
                          $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						  
					   }else if($coa->increasetypeid==2){
						   $type='Payment'; 
                           $camount=$valu->amount;
						   $bamount=$bamount-$valu->amount;
                           $damount=NULL; 
                           $link='http://192.168.1.8/IMS/voucher/pdf/'.$valu->id.'/'.$valu->type;						   
					   }  					   
					}
				}else{
					$pettycash = DB::table('pettycash')->where('id',$valu->id)->first();				
					$coa = DB::table('coa')->where('id',$pettycash->particular)->first();
					$vnno=$coa->name;
					//echo $vnno;
					if($coa->increasetypeid==2){
						  $type='Receipt'; 
                          $damount=$valu->amount;
                          $camount=NULL;
                          $bamount=$bamount+$valu->amount; 						  
					   }else if($coa->increasetypeid==1){
						   $type='Payment';
						   $damount=NULL;
                           $camount=$valu->amount;	
                           $bamount=$bamount-$valu->amount;						   
					   }  
					 $link='http://192.168.1.8/IMS/ledgerentry/pdf/'.$valu->id;  
				}
				$html='<tr><td style="background-color:#ffffff;">&nbsp;'.date('d-m-Y', strtotime($valu->created_at)).'</td>
			    <td style="background-color:#ffffff;">'.$vnno.'</td>
				<td style="background-color:#ffffff;">'.$type.'</td>
				<td style="background-color:#ffffff;"><a href="'.$link.'">'.$valu->vnno.'</a></td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($damount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($camount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bamount, 2, '.', '')).'</td>
				</tr>';
				$html2=$html2.$html;
				$i++;
				$dtotal=$dtotal+$damount;
		        $ctotal=$ctotal+$camount;
		} 			
		$html3='<tr>
				<td colspan="4" >Total</td>
				<td>'.CommonController::convertmoneyformat(number_format($dtotal, 2, '.', '')).'</td>
				<td>'.CommonController::convertmoneyformat(number_format($ctotal, 2, '.', '')).'</td>
				<td>'.CommonController::convertmoneyformat(number_format($bamount, 2, '.', '')).'</td>
			  </tr>
		</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($bamount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		    PDF::Output('cash.pdf');


		
	}
	
			

}
