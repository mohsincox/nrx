<?php namespace App\Http\Controllers;
use App\Http\Controllers\Common\CommonController;
use App\Http\Controllers\Controller;
use App\Models\Purchase;
use App\Models\Voucher;
use App\Models\Companyprofile;
use App\Models\Physicalsale;
use App\Models\Combo;
use App\Models\Info;
use App\Models\Sale;
use App\Models\Bankaccount;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\Factoryitem;
use PDF;
use DB;
class SearchController  extends Controller {	
	public function index()
	{
		 $profile=Companyprofile::get();
		return view('searchreturn')->with('profile',$profile);
	}
    
	public function searchreturn(Request $request)
	{
		$factioyitems = DB::table('factioyitems')->where('slno',$request->input('slno'))->first();
		$profile=Companyprofile::get();
		if($factioyitems!=NUll){
		    $factioyitems = DB::table('factioyitems')->where('slno',$request->input('slno'))->first();
			$factioyitems->salesid;
			$fiall = DB::table('factioyitems')			            
						 ->join('sales', 'sales.id', '=', 'factioyitems.salesid')
						 ->join('customers', 'customers.id', '=', 'sales.customerid')
						 ->join('items', 'items.id', '=', 'factioyitems.itemsid')
						 ->select('customers.name as cname','factioyitems.id as itemid', 'factioyitems.slno','factioyitems.updated_at as sdate','factioyitems.rstatus','factioyitems.randno','factioyitems.dstatus','factioyitems.updated_at as sdate', 'customers.preaddress', 'customers.phone', 'sales.name as salesname', 'sales.created_at as salesdate', 'items.name as itemsname')
						 ->where('salesid',$factioyitems->salesid)
						 ->get();
	  	return view('searchreturn2', compact('profile', 'fiall'));
		}
		else{
		$profile=Companyprofile::get();
		return view('searchreturn')->with('profile',$profile);
		}
    }
	
}
