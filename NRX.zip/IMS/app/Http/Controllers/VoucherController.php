<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Companyprofile;
use App\Models\Voucher;
use App\Models\Physicalsale;
use App\Models\Voucherbankpayment;
use App\Models\Voucherpayment;
use App\Models\Voucherbankreceive;
use App\Models\Voucherreceive;
use App\Models\Vouchercontra;
use App\Models\Voucherbkash;
use App\Models\Vouchersap;
use App\Models\Voucherkcs;
use App\Models\Vouchermbank;
use App\Models\Customersledger;
use App\Models\Suppliersledger;
use App\Http\Controllers\Common\CommonController;
use App\Models\Bankaccount;
use App\Models\Bankbook;
use App\Models\Customer;
use App\Models\Supplier;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\Info;
use PDF;
use DB;
use Auth;

class VoucherController  extends Controller {
	
	public function __construct()
	{
		$this->middleware('auth');
		$permission = \App\Http\Controllers\Common\CommonController::check_permission('voucher');
		if($permission == 0){
			echo 'This url is not found.';die();
			return redirect('/home');
		}
	}
	
	public function index()
	{
		$s=Supplier::get();
		$c=Customer::get();
		$bankaccount=Bankaccount::joining();
		$voucher = Voucher::orderBy('id', 'desc')->where('type','<>',5)->take(10)->get();
		return view('voucher', compact('bankaccount', 'c','s','voucher'));
	}
	
	public function register(Request $request)
	{
		$v= new Voucher();
		
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('supplieramount');
		$v->status = 2;
		$v->type = 1;
		$v->sid = $request->input('sid');
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Voucherbankpayment();
          $m->vid = $LastInsertId;		  
		  $m->baccid = $request->input('baccid');		 
		  $m->sid = $request->input('sid');	  
		  $m->checkno = $request->input('checkno');
		  $m->userid = $request->input('userid');	
		  $m->save();
		  $b=new Bankbook();
          $b->vid = $LastInsertId;		  
		  $b->baccid = $request->input('baccid');		 
		  $b->sid = $request->input('sid');	
          $b->dc = 0;
		  $b->amount = $request->input('amount');	
		  $b->checkno = $request->input('checkno');
		  $b->userid = $request->input('userid');	
		  $b->save();
		}
         $c = new Suppliersledger();
		$c->pav=$LastInsertId;
		$c->sid = $request->input('sid');
		$c->amount = $request->input('amount');
		$c->save();			
		return redirect('voucher');
	}
	public function registerp(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('samount');
		$v->status = 2;
		$v->type = 2;
		$v->sid = $request->input('sid');
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Voucherpayment();
          $m->vid = $LastInsertId;		  
		  $m->baccid = $request->input('baccid');	
		  
		  $m->sid = $request->input('sid');
		  
		  
		  $m->userid = $request->input('userid');	
		  $m->save();
		}	
        $c = new Suppliersledger();
		$c->pav=$LastInsertId;
		$c->sid = $request->input('sid');
		$c->amount = $request->input('amount');
		$c->save();	 		
		return redirect('voucher');
	}
	public function registerc(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('camount');
		$v->status = 1;
		$v->type = 3;
		$v->cid = $request->input('cid');	
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Voucherbankreceive();
          $m->vid = $LastInsertId;		  
		  $m->baccid = $request->input('baccid');		 
		  $m->cid = $request->input('cid');	  
		  $m->checkno = $request->input('checkno');
		  $m->userid = $request->input('userid');	
		  $m->save();
		  $b=new Bankbook();
          $b->vid = $LastInsertId;		  
		  $b->baccid = $request->input('baccid');		 
		  $b->cid = $request->input('cid');	  
		  $b->checkno = $request->input('checkno');
		  $b->dc = 1;
		  $b->amount = $request->input('amount');
		  $b->userid = $request->input('userid');	
		  $b->save();
		}
        $c = new Customersledger();
		$c->rv=$LastInsertId;
		$c->cid = $request->input('cid');
		$c->amount = $request->input('camount');
		$c->save();		
		return redirect('voucher');
	}
	public function registerr(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('camount');
		$v->status = 1;
		$v->type = 4;
		$v->cid = $request->input('cid');
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Voucherreceive();
          $m->vid = $LastInsertId;		  
		  $m->baccid = $request->input('baccid');		 
		  $m->cid = $request->input('cid');	  
		  //$m->checkno = $request->input('checkno');
		  $m->userid = $request->input('userid');	
		  $m->save();
		}
        $c = new Customersledger();
		$c->rv=$LastInsertId;
		$c->cid = $request->input('cid');
		$c->dc = 1;
		$c->amount = $request->input('camount');
		$c->save();		
		return redirect('voucher');
	}
	public function registercontra(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('bamount');
		$v->status = 3;
		$v->type = 5;
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Vouchercontra();
          $m->vid = $LastInsertId;		  
		  $m->baccid = $request->input('baccid');		 
		  //$m->cid = $request->input('cid');	  
		  $m->checkno = $request->input('checkno');
		  $m->userid = $request->input('userid');	
		  $m->save();
		}	 
		return redirect('voucher');
	}
	  //$m->checkno = $request->input('checkno');
		  //$m->userid = $request->input('userid');	
	public function registerbkash(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('camount');
		$v->status = 1;
		$v->type = 6;
		$v->cid = $request->input('cid');
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Voucherbkash();
          $m->vid = $LastInsertId;		  
		  $m->bkashno = $request->input('bkashno');		 
		  $m->cid = $request->input('cid');
		  $m->userid = $request->input('userid');
		  $m->save();
		}	
        $c = new Customersledger();
		$c->rv=$LastInsertId;
		$c->cid = $request->input('cid');
		$c->amount = $request->input('camount');
		$c->save();				
		return redirect('voucher');
	}
	
	public function registersap(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('camount');
		$v->status = 1;
		$v->type = 7;
		$v->cid = $request->input('cid');
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Vouchersap();
          $m->vid = $LastInsertId;		  
		  $m->sapno = $request->input('sapno');		 
		  $m->cid = $request->input('cid');
		  $m->userid = $request->input('userid');
		  $m->save();
		}
        $c = new Customersledger();
		$c->rv=$LastInsertId;
		$c->cid = $request->input('cid');
		$c->amount = $request->input('camount');
		$c->save();		
		return redirect('voucher');
	}
	
	public function registerkcs(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('camount');
		$v->status = 1;
		$v->type = 8;
		$v->cid = $request->input('cid');
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Voucherkcs();
          $m->vid = $LastInsertId;		  
		  $m->kcsno = $request->input('kcsno');		 
		  $m->cid = $request->input('cid');
		  $m->userid = $request->input('userid');
		  $m->save();
		}
         $c = new Customersledger();
		$c->rv=$LastInsertId;
		$c->cid = $request->input('cid');
		$c->amount = $request->input('camount');
		$c->save(); 		
		return redirect('voucher');
	}
	
	public function registermbank(Request $request)
	{
		$v= new Voucher();
		$sales = DB::table('voucher')->orderBy('id', 'desc')->first();
				 if($sales!=NULL){
				    $v->slno=$sales->slno+1;
				 }else{
					 $v->slno=1;
				 }
				 $prefix='V-';
				 if($v->slno<10){
						$v->vnno=$prefix.'000000'.$v->slno;
					}else if($v->slno<100){
						$v->vnno=$prefix.'00000'.$v->slno;
					}else if($v->slno<1000){
						$v->vnno=$prefix.'0000'.$v->slno;
					}else if($v->slno<10000){
						$v->vnno=$prefix.'000'.$v->slno;
					}else if($v->slno<100000){
						$v->vnno=$prefix.'00'.$v->slno;
					}else if($v->slno<1000000){
						$v->vnno=$prefix.'0'.$v->slno;
					}
		
		//$v->vnno = $request->input('vnno');
		//$v->vnno = $request->input('vnno');	
		$v->vdate = CommonController::date_format($request->input('vdate'));
		$v->amount = $request->input('amount');
		$v->amount = $request->input('camount');
		$v->status = 1;
		$v->type = 9;
		$v->cid = $request->input('cid');
		$v->userid = $request->input('userid');
		$v->save();
	    $LastInsertId = $v->id;
		if($LastInsertId!=NULL){
		  $m = new Vouchermbank();
          $m->vid = $LastInsertId;		  
		  $m->mbankno = $request->input('mbankno');		 
		  $m->cid = $request->input('cid');
		  $m->userid = $request->input('userid');
		  $m->save();
		}	
         $c = new Customersledger();
		$c->rv=$LastInsertId;
		$c->cid = $request->input('cid');
		$c->amount = $request->input('camount');
		$c->save();		
		return redirect('voucher');
	}
	
	public function pdf(Request $request,$id,$type)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		//echo $id.$type;
			$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$cid=$com->id;
			$coname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		
		if($type==1)
		{	
		$var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){		
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$bname=$v->bname;
			$branchname=$v->branchname;
			$accno=$v->accno;
			$checkno=$v->checkno;
			$vdate=$v->vdate;
			$baid=$v->baid;
			$sid=$v->sid;
			$bacode=$v->bacode;
			$scode=$v->scode;
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>Bank Payment Voucher</u></h2>
								 <table border="0" style="width:100%">
									<tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
										
										<td>Bank Name:'.$bname.'</td>
										<td></td>
										<td>Branch Name:'.$branchname.'</td>
										
									</tr>
									<tr>
										<td>A/C No.'.$accno.'</td>
										<td></td>
										<td>Check No.'.$checkno.'</td>
										
									  </tr>
									<tr>
								   
									<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
									</tr>
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$sname = DB::table('suppliers')->where('id',$sid)->pluck('name');
        $bname = DB::table('bankaccount')->where('id',$baid)->pluck('name');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sname.'</td>
				<td style="background-color:#ffffff;">'.$scode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$bname.'</td>
				<td style="background-color:#ffffff;">'.$bacode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbp.pdf');
		
		}
	
		else if($type==2)
			{	
		$var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$sid=$v->sid;
			$scode=$v->scode;
			$vdate=$v->vdate;
		
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
					
					<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>Payment Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
										<td>Unit/Place:</td>
										<td></td>
										<td>Manual V. No.</td>
										
									</tr>
									
									<tr>
								   
									<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
									</tr>
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$sname = DB::table('suppliers')->where('id',$sid)->pluck('name');
     	$cashname = DB::table('coa')->where('id',1)->pluck('name');
        $cashcode = DB::table('coa')->where('id',1)->pluck('code');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sname.'</td>
				<td style="background-color:#ffffff;">'.$scode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cashname.'</td>
				<td style="background-color:#ffffff;">'.$cashcode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbpp.pdf');
		
		}
		
		
		else if($type==3)
		{	
	                  $var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$bname=$v->bname;
			$branchname=$v->branchname;
			$accno=$v->accno;
			$checkno=$v->checkno;
			$vdate=$v->vdate;
			$baid=$v->baid;
			$cid=$v->cid;
			$bacode=$v->bacode;
			$ccode=$v->ccode;
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>Bank Receive Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
										<td>Bank Name:'.$bname.'</td>
										<td></td>
										<td>Branch Name:'.$branchname.'</td>
										
									</tr>
									<tr>
										<td>A/C No.'.$accno.'</td>
										<td></td>
										<td>Check No.'.$checkno.'</td>
										
									  </tr>
									<tr>
								   
									<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
									</tr>
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$cname = DB::table('customers')->where('id',$cid)->pluck('name');
        $bname = DB::table('bankaccount')->where('id',$baid)->pluck('name');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$bname.'</td>
				<td style="background-color:#ffffff;">'.$bacode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cname.'</td>
				<td style="background-color:#ffffff;">'.$ccode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbp.pdf');
		}
		else if($type==4){
				
		$var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$cid=$v->cid;
			$ccode=$v->ccode;
			$vdate=$v->vdate;
		
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>Receive Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
									
										<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
										
									</tr>
									
								
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$cname = DB::table('customers')->where('id',$cid)->pluck('name');
     	$cashname = DB::table('coa')->where('id',1)->pluck('name');
        $cashcode = DB::table('coa')->where('id',1)->pluck('code');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cashname.'</td>
				<td style="background-color:#ffffff;">'.$cashcode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cname.'</td>
				<td style="background-color:#ffffff;">'.$ccode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbpp.pdf');
		
		}
		else if($type==5){
				
			 $var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$bname=$v->bname;
			$baname=$v->baname;
			$branchname=$v->branchname;
			$checkno=$v->checkno;
			$vdate=$v->vdate;
			$baid=$v->baid;
			$bacode=$v->bacode;
			
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>Contra Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
										<td>Bank Name:'.$bname.'</td>
										<td></td>
										<td>Branch Name:'.$branchname.'</td>
										
									</tr>
									<tr>
										<td>A/C No.'.$baname.'</td>
										<td></td>
										<td>Check No.'.$checkno.'</td>
										
									  </tr>
									<tr>
								   
									<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
									</tr>
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$cashname = DB::table('coa')->where('id',1)->pluck('name');
        $cashcode = DB::table('coa')->where('id',1)->pluck('code');
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cashname.'</td>
				<td style="background-color:#ffffff;">'.$cashcode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$baname.'</td>
				<td style="background-color:#ffffff;">'.$bacode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbp.pdf');
		}
		
		else if($type==6){
				
		$var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$cid=$v->cid;
			$ccode=$v->ccode;
			$vdate=$v->vdate;
		
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>bKash Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
									
										<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
										
									</tr>
									
								
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$cname = DB::table('customers')->where('id',$cid)->pluck('name');
     	$cashname = DB::table('coa')->where('id',1)->pluck('name');
        $cashcode = DB::table('coa')->where('id',1)->pluck('code');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cashname.'</td>
				<td style="background-color:#ffffff;">'.$cashcode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cname.'</td>
				<td style="background-color:#ffffff;">'.$ccode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbpp.pdf');
		
		}
		
		else if($type==7){
				
		$var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$cid=$v->cid;
			$ccode=$v->ccode;
			$vdate=$v->vdate;
		
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>SAP Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
									
										<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
										
									</tr>
									
								
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$cname = DB::table('customers')->where('id',$cid)->pluck('name');
     	$cashname = DB::table('coa')->where('id',1)->pluck('name');
        $cashcode = DB::table('coa')->where('id',1)->pluck('code');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cashname.'</td>
				<td style="background-color:#ffffff;">'.$cashcode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cname.'</td>
				<td style="background-color:#ffffff;">'.$ccode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbpp.pdf');
		
		}
		
		
		else if($type==8){
				
		$var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$cid=$v->cid;
			$ccode=$v->ccode;
			$vdate=$v->vdate;
		
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>KCS Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
									
										<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
										
									</tr>
									
								
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$cname = DB::table('customers')->where('id',$cid)->pluck('name');
     	$cashname = DB::table('coa')->where('id',1)->pluck('name');
        $cashcode = DB::table('coa')->where('id',1)->pluck('code');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cashname.'</td>
				<td style="background-color:#ffffff;">'.$cashcode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cname.'</td>
				<td style="background-color:#ffffff;">'.$ccode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbpp.pdf');
		
		}
		
		else if($type==9){
				
		$var = array($id,$type);
	 	$spname="voucher";
	 	$value=Info::callinfo($var,$spname);
		//print_r($value);
		foreach($value as $v){	
			$vrno=$v->vrno;
			$mvno=$v->mvno;
			$amount=$v->amount;
			$cid=$v->cid;
			$ccode=$v->ccode;
			$vdate=$v->vdate;
		
		
		}
	    $date=date_create($vdate); 
		PDF::AddPage();
		
	      
		$html1='
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
				<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>MBank Voucher</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Voucher No:'.$vrno.'</td>
										<td></td>
										<td>Manual V. No:'.$mvno.'</td>
										
									</tr>
									<tr>
									
										<td>Month:'.date_format($date," F,Y").'</td>
										<td></td>
										<td>Date:'.date('d-m-Y', strtotime($vdate)).'</td>
										
									</tr>
									
								
								</table> 
							</div>
					
					
			
			
				
		
		  <div> </div>
		  <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">	
			  <tr>
				<th style="width:10%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL</th>
				<th style="width:30%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Head of Accounts</th>
				<th style="width:20%">&nbsp;&nbsp;&nbsp;&nbsp;A/C Code</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;DR(BDT)</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;CR(BDT)</th>
			  </tr>';
		$cname = DB::table('customers')->where('id',$cid)->pluck('name');
     	$cashname = DB::table('coa')->where('id',1)->pluck('name');
        $cashcode = DB::table('coa')->where('id',1)->pluck('code');		
		$html2= '<tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cashname.'</td>
				<td style="background-color:#ffffff;">'.$cashcode.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;"></td>
			  </tr>
			  <tr>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cname.'</td>
				<td style="background-color:#ffffff;">'.$ccode.'</td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>
			   <tr>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;"></td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total:</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($amount).'</td>
			  </tr>';
		
		$html3='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($amount, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('vbpp.pdf');
		
		}
	}
	
    public function save_approved(Request $request)
	{
		    
			if($request->ajax()){
				$sales_id=$request->input('sales_id');
				$voucher=Voucher::find($sales_id);
				
				if(!empty($voucher)){
					
					 if((($voucher->sid == NULL) && ($voucher->cid != NULL))){
						$customer = Customer::find($voucher->cid);
						//print_r($customer);die();
						$sales = Physicalsale::where('status', 1)
										 ->where('customerid',$voucher->cid)
										 ->where('presentbalance','<>',0)
										 ->orderBy('id', 'desc')
										 ->get();
				       	foreach($sales as $s){
							$s->presentbalance=$s->presentbalance - $voucher->amount;
							$s->previousdue=$s->previousdue - $voucher->amount;
							/*if($s->presentbalance<=0){
								$s->presentbalance=0;
							}
							if ($s->previousdue<=0){
								$s->previousdue=0;
							}
							*/
							$s->save();
						}
						$salesasc = Physicalsale::where('status', 1)
										 ->where('customerid',$voucher->cid)
										 ->orderBy('id', 'asc')
										 ->get();
						//print_r($salesasc);die();				 
						foreach($salesasc as $sasc){
							$presentbalance=$sasc->presentbalance;
						}
                        $customer->lastdue=$presentbalance;
						$customer->save();
					}
					$voucher->vstatus = 1;
					$voucher->save();
				}else{
					return response()->json(0);
				}
				return response()->json(1);
			}
	}
	
	public function save_unapproved(Request $request)
	{
		    
			if($request->ajax()){
				$sales_id=$request->input('sales_id');
				$voucher=Voucher::find($sales_id);
				if(!empty($voucher)){
					 if((($voucher->sid == NULL) && ($voucher->cid != NULL))){
						$customer = Customer::find($voucher->cid);
						$sales = Physicalsale::where('status', 1)
										 ->where('customerid',$voucher->cid)
										 ->where('presentbalance','<>',0)
										 ->orderBy('id', 'desc')
										 ->get();
				       	foreach($sales as $s){
							$s->presentbalance=$s->presentbalance + $voucher->amount;
							$s->previousdue=$s->previousdue + $voucher->amount;
							$s->save();
						}
						$salesasc = Physicalsale::where('status', 1)
										 ->where('customerid',$voucher->cid)
										 ->orderBy('id', 'asc')
										 ->get();
						foreach($salesasc as $sasc){
							$presentbalance=$sasc->presentbalance;
						}
                        $customer->lastdue=$presentbalance;
						$customer->save();
					}
					$voucher->vstatus = 0;
					$voucher->save();
				}else{
					return response()->json(0);
				}
				return response()->json(1);
			}
	}
	public function voucherlist(Request $request,$fromdate,$todate,$type){
		
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		$profile=Companyprofile::get();
		//print_r($profile); die();
		foreach($profile as $com){
			$id=$com->id;
			$coname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		
		if($type==11){
			$print_value=DB::table('purchase')
						->select(DB::raw('created_at,11 as particulars,gross_total as amount,id,name as vno'))
						->whereBetween('created_at',array($fromdate,$todate))
						->get();
			$voucher_name='Purchase';			
			//print_r($print_value);			
		}else if($type==12){
			$print_value=DB::table('sales')
						->select(DB::raw('created_at,12 as particulars,gamount as amount,id,name as vno'))
						->whereBetween('created_at',array($fromdate,$todate))
						->get();
			$voucher_name='Sales';			
			//print_r($print_value);			
		}else if($type==1 OR $type==2 OR $type==3 OR $type==4 OR $type==5 OR $type==6 OR $type==7 OR $type==8 OR $type==9){
			$print_value=DB::table('voucher')
						->select(DB::raw('created_at,type as particulars,amount,id,vnno as vno'))
						->where('type',$type)
						->whereBetween('created_at',array($fromdate,$todate))
						->get();
			if($type==1){
					$voucher_name='Bank Payment';
				}else if($type==2){
					$voucher_name='Cash Payment';
				}else if($type==3){
					$voucher_name='Bank receive';
				}else if($type==4){
					$voucher_name='Cash receive';
				}else if($type==5){
					$voucher_name='Contra';
				}else if($type==6){
					$voucher_name='Bkash';
				}else if($type==7){
					$voucher_name='SAP';
				}else if($type==8){
					$voucher_name='KCS';
				}else if($type==9){
					$voucher_name='Mbank';
				}		
			//print_r($print_value);			
		}else {
			$print_value=DB::table('pettycash')
						->select(DB::raw('created_at,particular as particulars,amount,id,id as vno'))
						->where('particular',$type)
						->whereBetween('created_at',array($fromdate,$todate))
						->get();
			$coa=DB::table('coa')->where('id',$type)->first();
            $voucher_name=$coa->name;			
			//print_r($print_value);			
		}
		//print_r($print_value);
	    //die();
		$fdate=date_create($fromdate);
		$tdate=date_create($todate);
		PDF::AddPage();
		PDF::SetMargins(5, 0, 5);
		$html1='
			
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$coname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
		
		<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						<u>List Of&nbsp;'.$voucher_name.'&nbsp;Voucher</u></h2>
						<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						
								'.date_format($fdate,"d-M-Y").'&nbsp;To&nbsp;'.date_format($tdate,"d-M-Y").'</h4>
								 
								 
							</div>
		
		  <div> 
		 
		   <table border="1" style="background-color:lightblue; width:100%; padding:20px;">		
			  <tr>
				<th style="width:8%;">SL No</th>
				<th style="width:13%;">&nbsp;Date</th>
				<th style="width:15%;">&nbsp;Particulars</th>
				<th style="width:15%;">Voucher Type</th>
				<th style="width:15%;">&nbsp;&nbsp;Voucher No</th>
				<th style="width:15%;">Debit Amount</th>
				<th style="width:15%;">Credit Amount</th>
				
				
			  </tr>
			 ';
			  
		
		
		$html2= '';
		 $i=1;
		 $totaldebit=0;
		 $totalcredit=0;
		 foreach($print_value as $valu){ 
		 
		
		//$damagedate=$c->updated_at;
		//$ddate=date_create($damagedate);
	   //echo date_format($ddate,"d-m-Y"); 
		 
				$sqldate=date_create($valu->created_at);
				$date=date_format($sqldate,"d-m-Y"); 
				$particulars=$valu->particulars;
				$amount=$valu->amount;
				$vno=$valu->vno;
				$id=$valu->id;
			    if($particulars==1){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$suppliers = DB::table('suppliers')->where('id',$voucher->sid)->first();
					$type=$suppliers->name;
					$vtype='Payment';
					//$coa = DB::table('coa')->where('id',7)->first();
					$increasetypeid=1;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/1';
				}else if($particulars==2){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$suppliers = DB::table('suppliers')->where('id',$voucher->sid)->first();
					$type=$suppliers->name;
					$vtype='Payment';
					//$coa = DB::table('coa')->where('id',7)->first();
					$increasetypeid=1;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/2';
				}else if($particulars==3){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$customers = DB::table('customers')->where('id',$voucher->cid)->first();
					$type=$customers->name;
					$vtype='Receive';
					$coa = DB::table('coa')->where('id',7)->first();
					$increasetypeid=2;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/3';
				}else if($particulars==4){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$customers = DB::table('customers')->where('id',$voucher->cid)->first();
					$type=$customers->name;
					$vtype='Receive';
					$coa = DB::table('coa')->where('id',7)->first();
					$increasetypeid=2;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/4';
				}else if($particulars==5){
					$type='Contra Voucher A/C';
					$vtype='Contra';
					$voucher= DB::table('voucher')->where('id',$id)->first();
					$increasetypeid=1;
					$link='http://192.168.1.3/IMS/contravoucher/pdf/'.$id.'/'.$particulars.'/'.$voucher->status;
				}else if($particulars==6){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$customers = DB::table('customers')->where('id',$voucher->cid)->first();
					$type=$customers->name;
					$vtype='Receive';
					$coa = DB::table('coa')->where('id',4)->first();
					$increasetypeid=$coa->increasetypeid;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/'.$particulars;
				}else if($particulars==7){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$customers = DB::table('customers')->where('id',$voucher->cid)->first();
					$type=$customers->name;
					$vtype='Receive';
					$coa = DB::table('coa')->where('id',5)->first();
					$increasetypeid=$coa->increasetypeid;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/'.$particulars;
				}else if($particulars==8){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$customers = DB::table('customers')->where('id',$voucher->cid)->first();
					$type=$customers->name;
					$vtype='Receive';
					$coa = DB::table('coa')->where('id',6)->first();
					$increasetypeid=$coa->increasetypeid;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/'.$particulars;
				}else if($particulars==9){
					$voucher = DB::table('voucher')->where('id',$id)->first();
					$customers = DB::table('customers')->where('id',$voucher->cid)->first();
					$type=$customers->name;
					$vtype='Receive';
					$coa = DB::table('coa')->where('id',7)->first();
					$increasetypeid=$coa->increasetypeid;
					$link='http://192.168.1.3/IMS/voucher/pdf/'.$id.'/'.$particulars;
				}else if($particulars==11){
					$purchase = DB::table('purchase')->where('id',$id)->first();
					$suppliers = DB::table('suppliers')->where('id',$purchase->suppliersid)->first();
					$type=$suppliers->name;
					$vtype='Purchase';
					$coa = DB::table('coa')->where('id',11)->first();
					$increasetypeid=$coa->increasetypeid;
					$link='http://192.168.1.3/IMS/purchase/pdf/'.$id;
				}else if($particulars==12){
					$sales = DB::table('sales')->where('id',$id)->first();
					$customers = DB::table('customers')->where('id',$sales->customerid)->first();
					$type=$customers->name;
					$vtype='Sales';
					$coa = DB::table('coa')->where('id',12)->first();
					$increasetypeid=$coa->increasetypeid;
					$link='http://192.168.1.3/IMS/physicalsales/print/'.$id;
				}else{
					$coa = DB::table('coa')->where('id',$particulars)->first();
					$increasetypeid=$coa->increasetypeid;
					$type=$coa->name;
					if($increasetypeid==1){
						$vtype='Receive';
					}else if($increasetypeid==2){
						$vtype='Payment';
					}
					
					$link='http://192.168.1.3/IMS/ledgerentry/pdf/'.$id;
				}
				
		 
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;'.$i.'</td>
				<td style="background-color:#ffffff;">&nbsp;'.$date.'</td>
				<td style="background-color:#ffffff;">'.$type.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;'.$vtype.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;<a href="'.$link.'" >'.$vno.'</a></td>';
				if($increasetypeid==1){
					$damount=$amount;
					$h1='<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat($damount).'</td>
					<td style="background-color:#ffffff;"></td>';
					$totaldebit=$totaldebit+$damount;
				}
				if($increasetypeid==2){
					$camount=$amount;
					$h1='<td style="background-color:#ffffff;"></td>
					<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat($camount).'</td>';
					$totalcredit=$totalcredit+$camount;
				}
				

				
				$h2='</tr>';
				$html=$html.$h1.$h2;
				$html2=$html2.$html;
				$i++; 
				
		 }
		if($totaldebit==0.00){
			$totaldebit="";
			$html3='<tr><td colspan="5" style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total</td>
					<td style="background-color:#ffffff;"></td>
					<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalcredit, 2, '.', '')).'</td>
				</tr></table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($totalcredit, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
					<div></div><div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>';
		}elseif($totalcredit==0.00){
			$totalcredit="";
			$html3='<tr><td colspan="5" style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total</td>
					<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totaldebit, 2, '.', '')).'</td>
					<td style="background-color:#ffffff;"></td>
				</tr></table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($totaldebit, 2, '.', '')).'&nbsp;Taka Only</h4></div>
		
				<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$coname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>';
		}
        
 		
	
		
		
		
						
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('voucherlist.pdf');
		
		
	}
	
	public function delete_info(Request $request)
	{
		    
			if($request->ajax()){
				$sales_id=$request->input('sales_id');
				
				$voucher=Voucher::find($sales_id);
				//print($voucher);die();
				if(!empty($voucher)){		
					$voucher->delete();
				}else{
					return response()->json(0);
				}
				return response()->json(1);
			}
	}
}
