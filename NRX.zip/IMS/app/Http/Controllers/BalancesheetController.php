<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Companyprofile;
use App\Models\Info;
use App\Models\Combo;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Common\CommonController;
use Session;
use PDF;
use DB;


class BalancesheetController  extends Controller {

	public function __construct()
	{
		$this->middleware('auth');
		$permission = \App\Http\Controllers\Common\CommonController::check_permission('customers');
		if($permission == 0){
			echo 'This url is not found.';die();
			return redirect('/home');
		}
	}

	public function index()
	{
		return view('balancesheet');
	}
	public function today(Request $request)
	{
	        $profile=Companyprofile::get();
		
		foreach($profile as $com){
			$cid=$com->id;
			$cname=$com->name;
			$aaddress=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
			//print_r($trialbalance);
			//die();
			
			$date=Combo::callcombo('currentdate');
			//print_r($date);
			foreach($date as $d){
				$curdate=$d->curdate;
			}
		   $from_temp_date=CommonController::date_format($curdate);
           $todate=CommonController::date_format($curdate);
		   $f_temp_date=date_create($from_temp_date);
		   $year=date_format($f_temp_date,"Y");
		   $fromdate="01-01-".$year;
		   $var = array($fromdate,$todate);
			//print_r($var);	
		   //  die();	
			
        $fdate=date_create($fromdate);
		$tdate=date_create($todate);
		PDF::AddPage();
		$capital_account_total= DB::table('pettycash')
		                       ->join('coa', 'coa.id', '=', 'pettycash.particular')
							   ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
							   ->where('coatype.id',20)
							   ->whereBetween('pettycash.created_at',array($fromdate,$todate))
		                       ->sum('amount'); 
		$html1='<p></p>
				<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$aaddress.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>
				</div>
			
					
					<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<u>Balance Sheet</u></h2>
						<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								'.date_format($fdate,"d-M-Y").'&nbsp;To&nbsp;'.date_format($tdate,"d-M-Y").'</h4>
								 
								 
							</div>

			<table border="1" style="background-color:#FFFFFF; padding:20px;">	
			  <tr>
			     <th><b>Liabilities</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;as at &nbsp;&nbsp;'.date_format($tdate,"d-M-Y").'</th>
				 <th><b>Assets</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;as at &nbsp;&nbsp;'.date_format($tdate,"d-M-Y").'</th>
			  </tr>
			  <tr>
			    <td>
				  <table border="0" style="background-color:#FFFFFF; padding:0px;">  
				     <tr><td><b>Capital Account</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>'.CommonController::convertmoneyformat($capital_account_total).'</b></td></tr>';
			$capital_html='';
            $capital_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',20)
							 ->select('coa.id as id','coa.name as coaname')
							 ->get();			 
			foreach($capital_account as $c){
				$capital_account_amount= DB::table('pettycash')
		                        ->where('particular',$c->id)
							   ->whereBetween('created_at',array($fromdate,$todate))
		                       ->sum('amount');
				$h1='<tr><td>'.$c->coaname.'</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($capital_account_amount).'</td></tr>';
			    $capital_html=$capital_html.$h1;
			}
			$loans_account_total= DB::table('pettycash')
		                       ->join('coa', 'coa.id', '=', 'pettycash.particular')
							   ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
							   ->where('coatype.id',1)
							   ->whereBetween('pettycash.created_at',array($fromdate,$todate))
		                       ->sum('amount');
			
			$loans_head='<tr><td><b>Loans(Liability)</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>'.CommonController::convertmoneyformat($loans_account_total).'</b></td></tr>';
			$loans_html='';
            $loans_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',1)
							 ->select('coa.id as id','coa.name as coaname')
							 ->get();			 
			foreach($loans_account as $c){
				$loans_account_amount= DB::table('pettycash')
		                        ->where('particular',$c->id)
							   ->whereBetween('created_at',array($fromdate,$todate))
		                       ->sum('amount');
				$h1='<tr><td>'.$c->coaname.'</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($loans_account_amount).'</td></tr>';
			    $loans_html=$loans_html.$h1;
			}	
			
			$current_liabalities_total= DB::table('sales')
			                    ->where('status',1)
		                        ->whereBetween('created_at',array($fromdate,$todate))
		                        ->sum('gamount');
			
            $current_liabalities_head='<tr><td><b>Current Liabilities</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>'.CommonController::convertmoneyformat($current_liabalities_total).'</b></td></tr>';
			$current_liabalities='';
            $current_liabalities_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',2)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($current_liabalities_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($current_liabalities_total).'</td></tr>';
			    $current_liabalities=$current_liabalities.$h1;
			}
			/*
            $placcount_head='<tr><td><b>Profit & Loss A/C</b></td></tr>';
			$placcount='';
            $placcount_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',12)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($placcount_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $placcount=$placcount.$h1;
			} 
            */  			
			$html2='
				  </table>
				</td>';
			
            $placcount_head='<tr><td><b>Profit & Loss A/C</b></td></tr>';
			$placcount='';
            $placcount_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',12)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($placcount_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $placcount=$placcount.$h1;
			}             
			$fixed_assets_total= DB::table('pettycash')
		                       ->join('coa', 'coa.id', '=', 'pettycash.particular')
							   ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
							   ->where('coatype.id',3)
							   ->whereBetween('pettycash.created_at',array($fromdate,$todate))
		                       ->sum('amount');
			
            $html3='<td>
				  <table border="0" style="background-color:#FFFFFF; padding:0px;">';
            
            $fixed_assets_head='<tr><td><b>Fixed Assets</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>'.CommonController::convertmoneyformat($fixed_assets_total).'</b></td></tr>';
			$fixed_assets='';
            $fixed_assets_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',3)
							 ->select('coa.id as id','coa.name as coaname')
							 ->get();			 
			foreach($fixed_assets_account as $c){
				$fixed_assets_amount= DB::table('pettycash')
		                        ->where('particular',$c->id)
							   ->whereBetween('created_at',array($fromdate,$todate))
		                       ->sum('amount');
				$h1='<tr><td>'.$c->coaname.'</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($fixed_assets_amount).'</td></tr>';
			    $fixed_assets=$fixed_assets.$h1;
			} 
			$current_assets_total=number_format(757350, 2, '.', '');
            $current_assets_head='<tr><td><b>Current Assets</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>'.CommonController::convertmoneyformat($current_assets_total).'</b></td></tr>';
			$current_assets='';
            $current_assets_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',4)
							 ->orwhere('coa.coatypeid',18)
							 ->select('coa.id as id','coa.name as coaname')
							 ->get();			 
			foreach($current_assets_account as $c){
				if($c->id==1){
					$current_assets_amount='333,500.00';
				}else if($c->id==10){
					$current_assets_amount='413,500.00';
				}else if($c->id==10){
					$current_assets_amount='103,500.00';
				}else if($c->id==24){
					$current_assets_amount=DB::table('purchase')
									->where('status',1)
									->whereBetween('created_at',array($fromdate,$todate))
									->sum('gross_total');
				}
				$h1='<tr><td>'.$c->coaname.'</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat($current_assets_amount).'</td></tr>';
			    $current_assets=$current_assets.$h1;
			}            
   			
				//     <tr><td><b>Fixed Assets</b></td></tr>
				//	 <tr><td><b>Current Assets</b></td></tr>
		   		
			$html4='</table>
				</td>
			  </tr>
			 </table>';
			 $total_liabilities=$capital_account_total+$loans_account_total+$current_liabalities_total;
			 $total_assets=$fixed_assets_total+$current_assets_total;
			 if($total_liabilities<=$total_assets){
				$html6='<table border="1" style="background-color:#FFFFFF; padding:20px;">
			        <tr>
					   <td>Differ From Opening Balance &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat(number_format($total_assets-$total_liabilities, 2, '.', '')).'</td>
					   <td></td>
					</tr>
			        </table>  '; 
			 }else if($total_assets<=$total_liabilities){
				$html6='<table border="1" style="background-color:#FFFFFF; padding:20px;">
			        <tr>
					   <td></td>
					   <td>Differ From Opening Balance &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat(number_format($total_liabilities-$total_assets, 2, '.', '')).'</td>
					</tr>
			        </table>  '; 
			 }
			$html5='
			         
			       <table border="1" style="background-color:#FFFFFF; padding:20px;">
			        <tr>
					   <td>Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat(number_format($capital_account_total+$loans_account_total+$current_liabalities_total, 2, '.', '')).'</td>
					   <td>Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.CommonController::convertmoneyformat(number_format($fixed_assets_total+$current_assets_total, 2, '.', '')).'</td>
					</tr>
			        </table>'; 
        /*   
 		$html=$html1.$capital_html.$loans_head.$loans_html.$current_liabalities_head.$current_liabalities.$placcount_head.$placcount.$html2.$html3.$fixed_assets_head.$fixed_assets.$current_assets_head.$current_assets.$html4;
        */
		$html=$html1.$capital_html.$loans_head.$loans_html.$current_liabalities_head.$current_liabalities.$html2.$html3.$fixed_assets_head.$fixed_assets.$current_assets_head.$current_assets.$html4.$html6.$html5;

        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('balancesheet.pdf');
            
	}
	
	 public function fromtoday(Request $request)
	{
		$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$cid=$com->id;
			$cname=$com->name;
			$aaddress=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		
			$fromdate=CommonController::date_format($request->input('fromdate'));
			$todate=CommonController::date_format($request->input('todate'));
            $var = array($fromdate,$todate);
	      
           // $var = array($fromdate,$todate);
			
		$var = array($fromdate,$todate);
		
        $fdate=date_create($fromdate);
		$tdate=date_create($todate);
		PDF::AddPage();
		 
		$html1='<p></p>
				<div>
						<table>
							<tr>
								<td style="width:20%">
									<img src="uploads/'.$file.'" alt="logo" height="150";>
								</td>
								<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$aaddress.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
								</td>
							</tr>

						</table>
				</div>
			
					
					<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<u>Balance Sheet</u></h2>
						<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								'.date_format($fdate,"d-M-Y").'&nbsp;To&nbsp;'.date_format($tdate,"d-M-Y").'</h4>
								 
								 
							</div>

			<table border="1" style="background-color:#FFFFFF; padding:20px;">	
			  <tr>
			     <th><b>Liabilities</b></th>
				 <th><b>Assets</b></th>
			  </tr>
			  <tr>
			    <td>
				  <table border="0" style="background-color:#FFFFFF; padding:0px;">  
				     <tr><td><b>Capital Account</b></td><td><b></b></td></tr>';
			$capital_html='';
            $capital_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',20)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($capital_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $capital_html=$capital_html.$h1;
			}
			
			
			$loans_head='<tr><td><b>Loans(Liability)</b></td></tr>';
			$loans_html='';
            $loans_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',1)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($loans_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $loans_html=$loans_html.$h1;
			}	
			
            $current_liabalities_head='<tr><td><b>Current Liabilities</b></td></tr>';
			$current_liabalities='';
            $current_liabalities_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',2)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($current_liabalities_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $current_liabalities=$current_liabalities.$h1;
			}
			
            $placcount_head='<tr><td><b>Profit & Loss A/C</b></td></tr>';
			$placcount='';
            $placcount_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',12)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($placcount_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $placcount=$placcount.$h1;
			} 
              			
			$html2='
				  </table>
				</td>';
			
            $placcount_head='<tr><td><b>Profit & Loss A/C</b></td></tr>';
			$placcount='';
            $placcount_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',12)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($placcount_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $placcount=$placcount.$h1;
			}             
			
            $html3='<td>
				  <table border="0" style="background-color:#FFFFFF; padding:0px;">';
            
            $fixed_assets_head='<tr><td><b>Fixed Assets</b></td></tr>';
			$fixed_assets='';
            $fixed_assets_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',3)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($fixed_assets_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $fixed_assets=$fixed_assets.$h1;
			} 
            $current_assets_head='<tr><td><b>Current Assets</b></td></tr>';
			$current_assets='';
            $current_assets_account=DB::table('coa')
			                 ->join('coatype', 'coatype.id', '=', 'coa.coatypeid')
			                 ->where('coa.coatypeid',4)
							 ->orwhere('coa.coatypeid',18)
							 ->select('coa.name as coaname')
							 ->get();			 
			foreach($current_assets_account as $c){
				$h1='<tr><td>'.$c->coaname.'</td><td><b></b></td></tr>';
			    $current_assets=$current_assets.$h1;
			}            
   			
				//     <tr><td><b>Fixed Assets</b></td></tr>
				//	 <tr><td><b>Current Assets</b></td></tr>
		   		
			$html4='</table>
				</td>
			  </tr>
			 </table>';

 		$html=$html1.$capital_html.$loans_head.$loans_html.$current_liabalities_head.$current_liabalities.$placcount_head.$placcount.$html2.$html3.$fixed_assets_head.$fixed_assets.$current_assets_head.$current_assets.$html4;


        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('balancesheet.pdf');
	}
}
