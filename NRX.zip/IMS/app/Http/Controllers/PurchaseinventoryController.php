<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Validator;
use App\Models\Purchaseinventory;
use App\Http\Requests;
use Illuminate\Http\Request;
use DB;


class PurchaseinventoryController  extends Controller {
	
	public function __construct()
	{
		$this->middleware('auth');
		$permission = \App\Http\Controllers\Common\CommonController::check_permission('purchaseinventory');
		if($permission == 0){
			echo 'This url is not found.';die();
			return redirect('/home');
		}
	}
	
	public function index()
	{
		$p=Purchaseinventory::pruchaseinvetoryinfo();
		return view('Purchaseinventory')->with('Purchaseinventory',$p);
	}
	public function addnew()
	{
		return view('createpurchaseinventory');
	}

	public function register(Request $request)
	{
		$total_purchase=DB::table('purchasedetails')->where('itemid','=',$request->input('itemsid'))->sum('quantity');
		$total_inventory=DB::table('purchaseinventory')->where('itemsid','=',$request->input('itemsid'))->sum('quantity');
		$munit=DB::table('items')
		     ->join('measurementunit', 'measurementunit.id', '=', 'items.mesid')   
		     ->where('items.id','=',$request->input('itemsid'))
			 ->select('measurementunit.name as mname')
			 ->first();
		$remaining_quantity=$total_purchase-$total_inventory;
		//echo $remaining_quantity; die();
		if($request->input('quantity')<=$remaining_quantity){
			$p = new Purchaseinventory();
			$p->itemsid = $request->input('itemsid');
			$p->quantity = $request->input('quantity');
			$p->userid = $request->input('userid');
			$p->save();
			return redirect('purchaseinventory');
		}else{
			$massege='Available product as '.$remaining_quantity.'  '.$munit->mname;
			return view('createpurchaseinventory')->with('massege',$massege);
		}
		
	}
}
