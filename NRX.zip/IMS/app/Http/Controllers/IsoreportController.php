<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Companyprofile;
use App\Models\Info;
use App\Models\Customer;
use App\Models\Combo;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Common\CommonController;
use Session;
use PDF;
use DB;
use Auth;
use Excel;

class IsoreportController  extends Controller {
	
	public function __construct()
	{
		$this->middleware('auth');
		$permission = \App\Http\Controllers\Common\CommonController::check_permission('isoreport');
		if($permission == 0){
			echo 'This url is not found.';die();
			return redirect('/home');
		}
	}
	
	public function index()
	{
		return view('isoreport');
	}
	
	
     public function today(Request $request)
	{
	        $date=Combo::callcombo('currentdate');
			//print_r($date);
			foreach($date as $d){
				$curdate=$d->curdate;
			}
			$fromdate=CommonController::date_format($curdate);
            $todate=CommonController::date_format($curdate);
			$fdate=$fromdate;
				$tdate=$todate;
			$customer_info=DB::table('customers')->select('id','name')->get();
			    $item_info=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
				           ->select('items.id as id','items.name as iname')
						   ->get();
				$item_info_cnt=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
						   ->select('items.id as itemid')
						   ->count();	
			/*//echo $fromdate.$todate;
			//return view('reportsaleview', compact('value','fromdate','todate'));
            $sales = DB::table('sales')
				->join('customers', 'customers.id', '=', 'sales.customerid')
				->join('salesdetails', 'salesdetails.salesid', '=', 'sales.id')
				->join('items', 'items.id', '=', 'salesdetails.itemid')
				->select('customers.name as customername', 'sales.name as salename', 'sales.created_at', 'items.name as itemname')
				->whereBetween('sales.created_at', [$fromdate, $todate])
				->get();*/
			//print_r($sales);
			return view('isoreportview', compact('customer_info','item_info','item_info_cnt','fdate','tdate'));
			
			
			/*Excel::create('ISOreport', function($excel) use($fromdate,$todate) {
			$excel->sheet('Excel sheet', function($sheet) use($fromdate,$todate) {
				$fdate=$fromdate;
				$tdate=$todate;
				$customer_info=DB::table('customers')->select('id','name')->get();
			    $item_info=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
				           ->select('items.id as id','items.name as iname')
						   ->get();
				$item_info_cnt=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
						   ->select('items.id as itemid')
						   ->count();		   
		//	$customers = Customer::orderBy('created_at','desc')->get();
			$sheet->loadView('ISOreport_download',compact('customer_info','item_info','item_info_cnt','fdate','tdate'));
			});
			})->export('xls');	*/
			
            
	
	}
	
	 public function fromtoday(Request $request)
	{
	        $fromdate=CommonController::date_format($request->input('fromdate'));
			$todate=CommonController::date_format($request->input('todate'));
            //echo $fromdate.$todate;
			$fdate=$fromdate;
				$tdate=$todate;
			$customer_info=DB::table('customers')->select('id','name')->get();
			    $item_info=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
						   // ->orderBy('items.id', 'asc')
				           ->select('items.id as id','items.name as iname')
						   ->get();
				$item_info_cnt=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
						   ->select('items.id as itemid')
						   ->count();	
				//print_r($customer_info);die();		   
				return view('isoreportview', compact('customer_info','item_info','item_info_cnt','fdate','tdate'));
			/*$sales = DB::table('sales')
				->join('customers', 'customers.id', '=', 'sales.customerid')
				->join('salesdetails', 'salesdetails.salesid', '=', 'sales.id')
				->join('items', 'items.id', '=', 'salesdetails.itemid')
				->select('customers.name as customername', 'sales.name as salename', 'sales.created_at', 'items.name as itemname')
				->whereBetween('sales.created_at', [$fromdate, $todate])
				->get();
			//print_r($sales);
			//return view('reportsaleview', compact('value','fromdate','todate'));
			
			
			Excel::create('ISOreport', function($excel) use($fromdate,$todate) {
			$excel->sheet('Excel sheet', function($sheet) use($fromdate,$todate) {
				$fdate=$fromdate;
				$tdate=$todate;
				$customer_info=DB::table('customers')->select('id','name')->get();
			    $item_info=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
				           ->select('items.id as id','items.name as iname')
						   ->get();
				$item_info_cnt=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
						   ->select('items.id as itemid')
						   ->count();		   
		//	$customers = Customer::orderBy('created_at','desc')->get();
			$sheet->loadView('ISOreport_download',compact('customer_info','item_info','item_info_cnt','fdate','tdate'));
			});
			})->export('xls');	*/
			
            
	}
	
	public function download(Request $request,$fdate,$tdate){
		Excel::create('ISOreport', function($excel) use($fdate,$tdate) {
			$excel->sheet('Excel sheet', function($sheet) use($fdate,$tdate) {
				//$fdate=$fromdate;
				//$tdate=$todate;
				$customer_info=DB::table('customers')->select('id','name')->get();
			    $item_info=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
				           ->select('items.id as id','items.name as iname')
						   ->get();
				$item_info_cnt=DB::table('items')
				           ->join('itemssubgroup', 'items.itemssubgroupid', '=', 'itemssubgroup.id')
						   ->where('itemssubgroup.itemgroupid','=',1)
						   ->select('items.id as itemid')
						   ->count();		   
		//	$customers = Customer::orderBy('created_at','desc')->get();
			$sheet->loadView('ISOreport_download',compact('customer_info','item_info','item_info_cnt','fdate','tdate'));
			});
			})->export('xls');
	}

}
