<?php namespace App\Http\Controllers;
use App\Http\Controllers\Common\CommonController;
use App\Http\Controllers\Controller;
use App\Models\Purchase;
use App\Models\Voucher;
use App\Models\Companyprofile;
use App\Models\Physicalsale;
use App\Models\Combo;
use App\Models\Info;
use App\Models\Sale;
use App\Models\Bankaccount;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\Factoryitem;
use PDF;
use DB;
use QrCode;
use Auth;
class HomeController extends Controller {


	public function __construct()
	{
		$this->middleware('auth');
	}
	public function voucherlist()
	{
		
		return view('voucherlist');
	}
	 public function today(Request $request)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
			$profile=Companyprofile::get();
		//print_r($profile); die();
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
	        $date=Combo::callcombo('currentdate');
			//print_r($date);
			foreach($date as $d){
				$curdate=$d->curdate;
			}
			$fromdate=CommonController::date_format($curdate);
            $todate=CommonController::date_format($curdate);
			$fromdate=date("Y-m-d");
            $todate=date("Y-m-d");
            $var = array($fromdate,$todate);
			 $var = array($fromdate,$todate);
			
			
			$purchasecnt=DB::table('purchase')
						->select(DB::raw('11 as type,COUNT(id) as count'))
						->whereBetween('created_at',array($fromdate,$todate));

			$salescnt=DB::table('sales')
						->select(DB::raw('12 as type,COUNT(id) as count'))
					    ->whereBetween('created_at',array($fromdate,$todate));
			
			$journalcnt=DB::table('pettycash')
						->select(DB::raw('particular as type,COUNT(particular) as count'))
						->groupBy('particular')
						 ->whereBetween('created_at',array($fromdate,$todate));
			
			$unionall=DB::table('voucher')
						->groupBy('type')
						->select('type',DB::raw('COUNT(type) as count'))
						->whereBetween('created_at',array($fromdate,$todate))
						->union($purchasecnt)
						->union($salescnt)
						->union($journalcnt)
						->get();
			//print_r($unionall);	die();
 foreach($unionall as $valu){ 
				$type=$valu->type;
				$count=$valu->count;
			
				
		 }
		    $fdate=date_create($fromdate);
		$tdate=date_create($todate);
		 PDF::AddPage();
		 
		$html1='
			
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
		
		<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						<u>List Of Vouchers</u></h2>
						<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						
						
								'.date_format($fdate,"d-M-Y").'&nbsp;To&nbsp;'.date_format($tdate,"d-M-Y").'</h4>
								 
								 
							</div>
		
		  <div> 
		 
		   <table border="1" style="background-color:lightblue; width:100%; padding:20px;">		
			  <tr>
				<th style="width:15%;">SL No</th>
				<th style="width:40%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Types of Voucher</th>
				<th style="width:25%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Count</th>
				
			  </tr>
			 ';
			  
		
		
		$html2= '';
		 $i=1;
		 $cnt=0;
		 foreach($unionall as $valu){ 
				$type=$valu->type;
				$count=$valu->count;
			    if($valu->type==1){
					$type='Bank Payment Voucher';
				}else if($valu->type==2){
					$type='Cash Payment Voucher';
				}else if($valu->type==3){
					$type='Bank receive Voucher';
				}else if($valu->type==4){
					$type='Cash receive Voucher';
				}else if($valu->type==5){
					$type='Contra Voucher';
				}else if($valu->type==6){
					$type='Bkash Voucher';
				}else if($valu->type==7){
					$type='SAP Voucher';
				}else if($valu->type==8){
					$type='KCS Voucher';
				}else if($valu->type==9){
					$type='Mbank  Voucher';
				}
				else if($valu->type==11){
					$type='Purchase Voucher';
				}
				else if($valu->type==12){
					$type='Sales Voucher';
				}
				else{
					$coa = DB::table('coa')->where('id', $valu->type)->first();
					$type=$coa->name.' Voucher';
				}
				
		 
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$type.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://192.168.1.3/IMS/voucherlist/'.$fromdate.'/'.$todate.'/'.$valu->type.'">'.$count.'</a></td>

				
				</tr>';
				$html2=$html2.$html;
				$i++; 
				$cnt=$cnt+$count;
		 }
		
        
 		$html3='<tr><td colspan="2" style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total</td>
					<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cnt.'</td>
				</tr></table></div>
		
				<div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>';
	
		
		
		
						
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('voucherlist.pdf');
		
         
	}
	
	 public function fromtoday(Request $request)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		$profile=Companyprofile::get();
		//print_r($profile); die();
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		
	        $fromdate=CommonController::date_format($request->input('fromdate'));
			$todate=CommonController::date_format($request->input('todate'));
			
            $var = array($fromdate,$todate);
			
			
			$purchasecnt=DB::table('purchase')
						->select(DB::raw('11 as type,COUNT(id) as count'))
						->whereBetween('created_at',array($fromdate,$todate));

			$salescnt=DB::table('sales')
						->select(DB::raw('12 as type,COUNT(id) as count'))
					    ->whereBetween('created_at',array($fromdate,$todate));
			
			$journalcnt=DB::table('pettycash')
						->select(DB::raw('particular as type,COUNT(particular) as count'))
						->groupBy('particular')
						 ->whereBetween('created_at',array($fromdate,$todate));
			
			$unionall=DB::table('voucher')
						->groupBy('type')
						->select('type',DB::raw('COUNT(type) as count'))
						->whereBetween('created_at',array($fromdate,$todate))
						->union($purchasecnt)
						->union($salescnt)
						->union($journalcnt)
						->get();
			//print_r($unionall);	die();
 foreach($unionall as $valu){ 
				$type=$valu->type;
				$count=$valu->count;
			
				
		 }
		    $fdate=date_create($fromdate);
		$tdate=date_create($todate);
		 PDF::AddPage();
		 
		$html1='
			<p></p>
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
		
		<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						<u>List Of Vouchers</u></h2>
						<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						
						
								'.date_format($fdate,"d-M-Y").'&nbsp;To&nbsp;'.date_format($tdate,"d-M-Y").'</h4>
								 
								 
							</div>
		
		  <div> 
		 
		   <table border="1" style="background-color:lightblue; width:100%; padding:20px;">		
			  <tr>
				<th style="width:15%;">SL No</th>
				<th style="width:40%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Types of Voucher</th>
				<th style="width:25%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Count</th>
				
			  </tr>
			 ';
			  
		
		
		$html2= '';
		 $i=1;
		 $cnt=0;
		 foreach($unionall as $valu){ 
				$type=$valu->type;
				$count=$valu->count;
			    if($valu->type==1){
					$type='Bank Payment Voucher';
				}else if($valu->type==2){
					$type='Cash Payment Voucher';
				}else if($valu->type==3){
					$type='Bank receive Voucher';
				}else if($valu->type==4){
					$type='Cash receive Voucher';
				}else if($valu->type==5){
					$type='Contra Voucher';
				}else if($valu->type==6){
					$type='Bkash Voucher';
				}else if($valu->type==7){
					$type='SAP Voucher';
				}else if($valu->type==8){
					$type='KCS Voucher';
				}else if($valu->type==9){
					$type='Mbank  Voucher';
				}
				else if($valu->type==11){
					$type='Purchase Voucher';
				}
				else if($valu->type==12){
					$type='Sales Voucher';
				}
				else{
					$coa = DB::table('coa')->where('id', $valu->type)->first();
					$type=$coa->name.' Voucher';
				}
				
		 
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$type.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://192.168.1.3/IMS/voucherlist/'.$fromdate.'/'.$todate.'/'.$valu->type.'">'.$count.'</a></td>

				
				</tr>';
				$html2=$html2.$html;
				$i++; 
				$cnt=$cnt+$count;
		 }
		
        
 		$html3='<tr><td colspan="2" style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total</td>
					<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$cnt.'</td>
				</tr></table></div>
		
<div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>';
	
		
		
		
						
		
        $html=$html1.$html2.$html3;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('voucherlist.pdf');
		
		 
          
	}

	
	public function index()
	{
		//echo QrCode::generate('Make me into a QrCode!');
		//die();
		$now = new \DateTime('now');
   		$month = $now->format('m');
		$c=Purchase::get();
		$c1=Physicalsale::get();
		$var = array($month);
		$spname="salesreport";
		$c2=Info::callinfo($var,$spname);
		$var1 = array($month-1);
		$spname1="salesreportp";
		$c3=Info::callinfo($var1,$spname1);
		$spname2="todaysales";
		$c4=Combo::callcombo($spname2);
		$spname3="todaycash";
		$c5=Combo::callcombo($spname3);
		$spname4="todaybankcollection";
		$c6=Combo::callcombo($spname4);
		$spname5="todaycashcollection";
		$c7=Combo::callcombo($spname5);
		$spname6="todaycontracollection";
		$c8=Combo::callcombo($spname6);
		$spbkash="todaybkashcollection";
		$bkash=Combo::callcombo($spbkash);
		$spsap="todaysapcollection";
		$sap=Combo::callcombo($spsap);
		$spkcs="todaykcscollection";
		$kcs=Combo::callcombo($spkcs);
		$spmbank="todaymbankcollection";
		$mbank=Combo::callcombo($spmbank);
       // print_r($c4);
		$sales_info = Sale::orderBy('created_at', 'desc')->take(5)->get();
		
		$purchase_info = Purchase::orderBy('created_at', 'desc')->take(5)->get();
		
		$bankaccount_info = Bankaccount::orderBy('created_at', 'desc')->take(5)->get();

		return view('home', compact('c', 'c1', 'c2', 'c3', 'sales_info', 'purchase_info', 'bankaccount_info','c4','c5','c6','c7','c8','bkash','sap','kcs','mbank'));
	}
	
	public function dailycollection()
	{
	    $spname="todaycollection";
		$c=Combo::callcombo($spname);
		$spname3="todaycash";
		$c5=Combo::callcombo($spname3);
		$spname4="todaybankcollection";
		$c6=Combo::callcombo($spname4);
		$spname5="todaycashcollection";
		$c7=Combo::callcombo($spname5);
		$spbkash="todaybkashcollection";
		$bkash=Combo::callcombo($spbkash);
		$spsap="todaysapcollection";
		$sap=Combo::callcombo($spsap);
		$spkcs="todaykcscollection";
		$kcs=Combo::callcombo($spkcs);
		$spmbank="todaymbankcollection";
		$mbank=Combo::callcombo($spmbank);
		//print_r($c);
		return view('dailycollection',compact('c','c5','c6','c7','bkash','sap','kcs','mbank'));
    }	
	
    public function search(Request $request)
	{
		$slno=$request->input('slno');
		//echo $slno; die();
		if($slno!=NULL){
			 $factioyitems=DB::table('factioyitems')->where('slno',$slno)->first();
			 if($factioyitems!=NULL){
				$sales=DB::table('sales')->where('id',$factioyitems->salesid)->first();
				$customers=DB::table('customers')->where('id',$sales->customerid)->first();
				$items=DB::table('items')->where('id',$factioyitems->itemsid)->first(); 
			 }
		}	   
		$profile=Companyprofile::get();
		return view('search',compact('profile','factioyitems','sales','customers','items','slno'));
    }
     
	public function replacepdf(Request $request,$id)
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
		//echo $id;
		
		 $returnpdf = DB::table('factioyitems')
				->join('sales', 'factioyitems.salesid', '=', 'sales.id')
				->join('customers', 'customers.id', '=', 'sales.customerid')
				->join('replace_factory', 'replace_factory.factoryitemsid', '=', 'factioyitems.id')
				->join('replacechallan', 'replace_factory.repalcechallanid', '=', 'replacechallan.id')
				->select('customers.id as cid','customers.name as cname','customers.phone as cphone','sales.name as inno','customers.preaddress as address','factioyitems.updated_at as date')
				//->where('factioyitems.rstatus',1)
				//->where('replacechallan.created_at',date("Y/m/d"))
				->where('replacechallan.id',$id)
				->get();
		$replace=DB::table('replacechallan')->where('replacechallan.id',$id)->first();		
		 //print_r($returnpdf); die();
		 foreach($returnpdf as $valu){ 
				$cid=$valu->cid;
				$sailname=$valu->inno;
				$salesdate=$valu->date;
				$cusname=$valu->cname;
				$phone=$valu->cphone;
				$preaddress=$valu->address;
				
		 } 
		 
		 $returnvalue = DB::table('factioyitems')
				->join('sales', 'factioyitems.salesid', '=', 'sales.id')
				->join('customers', 'customers.id', '=', 'sales.customerid')
				->join('replace_factory', 'replace_factory.factoryitemsid', '=', 'factioyitems.id')
				->join('replacechallan', 'replace_factory.repalcechallanid', '=', 'replacechallan.id')
			    ->join('items', 'factioyitems.itemsid', '=', 'items.id')
				->select('items.name as itemname','factioyitems.slno as slno','factioyitems.randno as randno','factioyitems.salesid as salesid')
				->where('replacechallan.cid',$cid)
				->where('replacechallan.id',$id)
				->get();
		//print_r($returnvalue);die();
		foreach($returnvalue as $r){
			$itemname=$r->itemname;
			$present_slno=$r->slno;
			$f = DB::table('factioyitems')->where('randno',$r->randno)->where('rstatus',0)->first();
			$previous_slno=$f->slno;
		}
		
		$profile=Companyprofile::get();
		//print_r($profile); die();
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		PDF::AddPage();
		 
		$html1='
			<p></p>
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
		
		<div>
					             <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;
						<u>REPALCE CHALLAN COPY</u></h2>
								 <table border="0" style="width:100%">
								 <tr>
										
										<td>Customer Name:'.$cusname.'</td>
										<td></td>
										<td>Replace Sl No:'.$replace->name.'</td>
										
									</tr>
									<tr>
									
										<td>Address:'.$preaddress.'</td>
										<td></td>
										<td>Date:'.$salesdate.'</td>
										
									</tr>
										<tr>
									
										<td>Mobile No:'.$phone.'</td>
										<td></td>
										<td></td>
										
									</tr>
									
								
								</table> 
							</div>
		
		  <div> 
		 
		   <table border="1 solid" style="background-color:lightblue; width:100%; padding:20px;">		
			  <tr>
				<th style="width:15%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SL No</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Item Model</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Replace SL NO</th>
				<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Invoice NO</th>
			  </tr>';
			  
		$html2= '';
		$i=1;
		foreach($returnvalue as $r){
			$itemname=$r->itemname;
			$present_slno=$r->slno;
			$f = DB::table('factioyitems')->where('randno',$r->randno)->where('rstatus',0)->first();
			$previous_slno=$f->slno;
		    $sales = DB::table('sales')->where('id',$r->salesid)->first();
	
				$html='<tr><td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$itemname.'</td>
				
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$present_slno.'</td>
				<td style="background-color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sales->name.'</td>
				
				</tr>';
				$html2=$html2.$html;
				$i++;
		}	
		$html3='';	
        
 		$html5='</table>';
	
		
		
		$html9='       <div></div><div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3.$html5.$html9;
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('challan.pdf');
		
		
		
		
    } 
	 
	 
     public function replace(Request $request)
	{
		$inno=$request->input('inno');
		$userid=$request->input('userid');
		$slno=$request->input('slno');
		$itemsid=$request->input('itemsid');
		$randomno=$request->input('randomno');
		//$f=DB::table('factioyitems')->where('id',$itemsid)->first();
		//echo $f->randno; die();
		//echo $inno; die();
		if($slno!=NULL){
			 $sales=DB::table('sales')->where('id',$inno)->first();
			 $replacechallan=DB::table('replacechallan')
			                 ->where('cid',$sales->customerid)
							 ->where('created_at',date('Y-m-d'))
							 ->first();
			 if($replacechallan==NULL){
				 $rchallanid=DB::table('replacechallan')->insertGetId(
                           ['name' => rand(), 'cid' => $sales->customerid,'userid' => $userid,'created_at' => date('Y-m-d')]
				 );
			 }else{
				$rchallanid=$replacechallan->id; 
			 }				 
			 DB::table('factioyitems')->where('id',$slno)->update(['salesid' => $inno]);
			 DB::table('factioyitems')->where('id',$slno)->update(['sale_product' => 1]);
		     DB::table('factioyitems')->where('id',$slno)->update(['rstatus' => 1]);
			 //DB::table('factioyitems')->where('id',$slno)->update(['same_status' => 1]);
			 $f=DB::table('factioyitems')->where('id',$itemsid)->first();
			 DB::table('replace_factory')->insert(['repalcechallanid' => $rchallanid, 'factoryitemsid' => $slno]);
			 if($slno==$itemsid){
					DB::table('factioyitems')->where('id',$itemsid)->update(['randno' => 0]);
					DB::table('factioyitems')->where('id',$itemsid)->update(['dstatus' =>0]);
					DB::table('factioyitems')->where('id',$itemsid)->update(['same_status' => 1]);
			}else{
				    if($f->randno==0){
						DB::table('factioyitems')->where('id',$itemsid)->update(['randno' => $randomno]);
						DB::table('factioyitems')->where('id',$itemsid)->update(['dstatus' => 1]); 
						DB::table('factioyitems')->where('id',$slno)->update(['randno' => $randomno]);
						
					 }else{
						DB::table('factioyitems')->where('id',$slno)->update(['randno' => $f->randno]);
						DB::table('factioyitems')->where('id',$itemsid)->update(['dstatus' => 1]);
						DB::table('factioyitems')->where('id',$itemsid)->update(['rstatus' => 0]);
										
					 }
			}
		     
		}	   
		$profile=Companyprofile::get();
		return view('search',compact('profile','factioyitems','sales','customers','items','slno'));
    }
	
	
    public function return_item(Request $request)
	{
		if($request->ajax()){
			$factory_item_id = $request->input('factory_item_id');
			$factory_item = Factoryitem::find($factory_item_id);
			if($factory_item !== null){
				$next_factory_item = Factoryitem::where('itemsid', $factory_item->itemsid)
													->where('status', 1)
													->where('salesid', NULL)
													->where('sale_product', 0)
													->first();
				if($next_factory_item !== null){
					$next_factory_item->salesid = $factory_item->salesid;
					$next_factory_item->sale_product = 1;
					$next_factory_item->save();

					$factory_item->status = 0;
					$factory_item->save();

					return response()->json(1);// return successfully
				} else{
					return response()->json(2);// Not available this item.
				}								

			} else{
				return response()->json(0);//Not found thid product.
			}
		}	
    }

    public function return_item_ina_to_act(Request $request)
	{
		if($request->ajax()){
			$factory_item_id = $request->input('factory_item_id');
			$factory_item = Factoryitem::find($factory_item_id);
			if($factory_item !== null){
				$last_update_factory_item = Factoryitem::where('itemsid', $factory_item->itemsid)
													->where('salesid', $factory_item->salesid)
													->where('status', 1)
													->where('sale_product', 1)
													->orderBy('id', 'DESC')
													->first();
				if($last_update_factory_item !== null){
					$last_update_factory_item->salesid = NULL;
					$last_update_factory_item->sale_product = 0;
					$last_update_factory_item->save();

					$factory_item->status = 1;
					$factory_item->save();

					return response()->json(1);// return successfully
				} else{
					return response()->json(2);// Not found last inactive
				}								

			} else{
				return response()->json(0);//Not found thid product.
			}
		}	
    }

	
	
	
	/*public function printcollection()
	{
	    return 'printcoleection';
    }	*/
		public function printcollection()
	{
		$users = DB::table('users')->where('id',Auth::id())->first();
		if(!empty($users->file)){
			$usersfile='<img src="uploads/'.$users->file.'" alt="logo" height="150";>';
		}else{
			$usersfile=NULL;
		}
	
		
		$profile=Companyprofile::get();
		
		foreach($profile as $com){
			$id=$com->id;
			$cname=$com->name;
			$address=$com->address;
			$tele=$com->telephone;
			$mobile=$com->mobile;
			$email=$com->email;
			$url=$com->url;
			$file=$com->file;
		}
		 $spname="todaycollection";
		$c=Combo::callcombo($spname);
		$spname3="todaycash";
		$c5=Combo::callcombo($spname3);
		$spname4="todaybankcollection";
		$c6=Combo::callcombo($spname4);
		$spname5="todaycashcollection";
		$c7=Combo::callcombo($spname5);
		$spname6="todaybkashcollection";
		$c8=Combo::callcombo($spname6);
		$spsap="todaysapcollection";
		$csap=Combo::callcombo($spsap);
		$spkcs="todaykcscollection";
		$ckcs=Combo::callcombo($spkcs);
		$spmbank="todaymbankcollection";
		$cmbank=Combo::callcombo($spmbank);
	foreach($c6 as $cc){ $totalbankcash=$cc->cash;}
	foreach($c7 as $ccc){ $totalhandcash=$ccc->cash;}
	foreach($c8 as $ccc){ $totalbkash=$ccc->cash;}	
	foreach($csap as $ccc){ $totalsap=$ccc->cash;}	
	foreach($ckcs as $ccc){ $totalkcs=$ccc->cash;}	
	foreach($cmbank as $ccc){ $totalmbank=$ccc->cash;}	
		$sum=0;
		foreach($c as $p){ 
				$a=$p->amount;	
				$sum=$sum+$a;
		} 
		
		PDF::AddPage('L');
		 
		$html1='
			<p></p>
				<div>
					<table>
						<tr>
							<td style="width:20%">
								<img src="uploads/'.$file.'" alt="logo" height="150";>
							</td>
							<td style="width:85% font-size:30%">
								<h2>'.$cname.'</h2>
								
								'.$address.'
									<br>Tel:'.$tele.',Mobile:'.$mobile.'
									<br>E-mail:'.$email.'
									<br>'.$url.'
								 
							</td>
						</tr>

					</table>	
				</div>
						
						<h2>
					    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<u>Statement of Collection</u></h2><h4><br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						Date: '. date("d-m-Y") .'  To  '. date("d-m-Y") .'</h4>
						</div>
						
				<table border="1" style="background-color:lightblue; width:100%; padding:20px;">	
					<tr>
						<th style="width:3%;">SL</th>
						<th style="width:10%;">Name</th>
						<th style="width:12%;">Present Address</th>
						<th style="width:7%;">Voucher No.</th>
						<th>Bank Amount</th>
						<th>Cash</th>
						<th>BKash</th>
						<th>SAP</th>
						<th>KCS</th>
						<th>MBank</th>
						<th>Total Cash</th>
						<th>Grand Total</th>
					</tr>';
				
		$html2= '';
		 $i=1;
		 $sum=0;
		$grand_total_cash=0.00;
		foreach($c as $p){ 
		        if($p->type==3){
					$bankamount=$p->amount;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==4){
					$bankamount=0.00;
					$cashamount=$p->amount;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==6){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=$p->amount;
					$sap=0.00;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==7){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=$p->amount;
					$kcs=0.00;
					$mbank=0.00;
				}else if($p->type==8){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=$p->amount;
					$mbank=0.00;
				}else if($p->type==9){
					$bankamount=0.00;
					$cashamount=0.00;
					$bkash=0.00;
					$sap=0.00;
					$kcs=0.00;
					$mbank=$p->amount;
				}
				$totalcash=$cashamount+$bkash+$sap+$kcs+$mbank;
				$html='<tr><td style="background-color:#ffffff;">'.$i.'</td>
				<td style="background-color:#ffffff;">'.$p->name.'</td>
				<td style="background-color:#ffffff;">'.$p->preaddress.'</td>
				<td style="background-color:#ffffff;"><a href="http://192.168.1.8/IMS/voucher/pdf/'.$p->id.'/'.$p->type.'"   target="_blank">'.$p->vnno.'</a></td>					
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bankamount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($cashamount, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($bkash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($sap, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($kcs, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($mbank, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($p->amount, 2, '.', '')).'</td>
				</tr>';
				$html2=$html2.$html;
				$i++;
				$sum=$sum+$p->amount;
				$grand_total_cash=$grand_total_cash+$totalcash;
		} 
		$html3='<tr><td colspan="4" align="right" style="background-color:#ffffff;">';
		$html4='';
		$html5='Total:</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalbankcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalhandcash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalbkash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalsap, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalkcs, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($totalmbank, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($grand_total_cash, 2, '.', '')).'</td>
				<td style="background-color:#ffffff;">'.CommonController::convertmoneyformat(number_format($sum, 2, '.', '')).'</td></tr>';
		$html6='</table><h4>Amount in word:'.CommonController::convertNumberToWord(number_format($sum, 2, '.', '')).' Taka Only</h4></div>
						<div></div><div></div><div></div><div>
				<table border="0" style="width:110%">

								 <tr>
										
										<td></td>
										<td>'.$usersfile.'</td>
										<td></td>
										
									</tr>
									<tr>
									
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										<td><h4>. . . . . . . . . . . . . . </h4></td>
										
									</tr>
									<tr>
									
										<td><h3>Received By</h3></td>
										<td><h3>Prepared By</h3></td>
										<td><h3>Approved By</h3></td>
										
									</tr>
									
									<tr>
									
										<td></td>
										<td></td>
										<td><h5>For&nbsp;'.$cname.'</h5></td>
										
									</tr>
								
								</table> 
					
					
						</div>'
						; 
		
        $html=$html1.$html2.$html3.$html4.$html5.$html6;
		
		
        			
		PDF::writeHTML($html, true, false, true, false, '');
		
		PDF::Output('collection.pdf');
		
		} 
		
		
	

}
