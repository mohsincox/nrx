<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Vouchercontra extends Model {

	protected $table = 'vouchercontra';

}