<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Voucherbkash extends Model {

	protected $table = 'voucherbkash';

}