<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Measurementgroup extends Model {

	protected $table = 'measurementgroup';

}

