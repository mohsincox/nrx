<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Submenus extends Model {

	protected $table = 'submenus';

}
