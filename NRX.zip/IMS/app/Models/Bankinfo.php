<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Bankinfo extends Model {

	protected $table = 'bankinfo';

}

