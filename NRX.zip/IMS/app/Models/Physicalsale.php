<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Physicalsale extends Model {

	protected $table = 'sales';

}