<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Taxrate extends Model {

	protected $table = 'taxrate';

}