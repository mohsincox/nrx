<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Vouchersap extends Model {

	protected $table = 'vouchersap';

}