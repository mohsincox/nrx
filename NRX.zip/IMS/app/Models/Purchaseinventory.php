<?php namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use DB;

class Purchaseinventory extends Model {

	protected $table = 'purchaseinventory';
	
	public static function pruchaseinvetoryinfo()
	{
		return DB::table('purchaseinventory')
			->join('items', 'purchaseinventory.itemsid', '=', 'items.id')
			->select('purchaseinventory.id','items.name','purchaseinventory.quantity','purchaseinventory.created_at')
			->get();
	}

}

